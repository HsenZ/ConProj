﻿// awwal sura

using AppSec.Repositorys;
using AppSec.Repositorys.Helpers;
using AppSec.Repositorys.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Telerik.WinControls.UI;

namespace AppSec.Forms
{
    public partial class FormWord2 : Form
    {
        private FormInvest fi;
        private int serialNo;
        private bool flag;
        public FormWord2()
        {
            InitializeComponent();
        }
        public FormWord2(Form callingForm)
        {
            InitializeComponent();
            fi = callingForm as FormInvest;
            serialNo = Convert.ToInt32(fi.SerialNo);


        }
        private void FormWord2_Load(object sender, EventArgs e)
        {
            DataTable dt = new SecEntities().DataTable("select * from [dbo].worldkey");
            radCheckedListBox1.DataSource = dt;
            radCheckedListBox1.DisplayMember = "LABEL";
            radCheckedListBox1.ValueMember = "CODE";
            radTextBox1.Text = serialNo.ToString();
            BindToMaboutDataSet();
            FillLists();
        }
        void FillLists()
        {

            if (!flag)
            {

                foreach (ListViewDataItem listViewDataItem in radCheckedListBox1.Items)
                    listViewDataItem.CheckState = Telerik.WinControls.Enumerations.ToggleState.Off;
                InvworldDB invworldDB = new InvworldDB();
                List<int> list = invworldDB.GetCodesById(serialNo);

                foreach (int i in list)
                {
                    for (int j = 0; j < radCheckedListBox1.Items.Count; j++)
                        if (Convert.ToInt32(radCheckedListBox1.Items[j].Value.ToString()) == i)
                            radCheckedListBox1.Items[j].CheckState = Telerik.WinControls.Enumerations.ToggleState.On;
                }
                flag = true;
                populatelistview();
            }
        }
        void populatelistview()
        {
            radListView1.Items.Clear();
            foreach (ListViewDataItem listViewDataItem in radCheckedListBox1.Items)
                if (listViewDataItem.CheckState == Telerik.WinControls.Enumerations.ToggleState.On)
                    radListView1.Items.Add(listViewDataItem.Text);
        }
        private void radCheckedListBox1_ItemCheckedChanged(object sender, Telerik.WinControls.UI.ListViewItemEventArgs e)
        {
            try
            {
                //  MessageBox.Show("label="+e.Item.Text+" Code="+e.Item.Value);
                InvworldDB invworldDB = new InvworldDB();
                Invworld invworld = new Invworld();
                if (flag == false) return;
                if (e.Item.CheckState == Telerik.WinControls.Enumerations.ToggleState.On)
                {
                    invworld.Ser = generateSerial();
                    invworld.Serial = serialNo;
                    invworld.Code = Convert.ToInt32(e.Item.Value.ToString());
                    invworldDB.AddNew(invworld);

                    BindToMaboutDataSet();
                }
                else
                {
                    int code = Convert.ToInt32(e.Item.Value.ToString());
                    invworldDB.RemoveWord2(serialNo, code);
                    //  RemoveFromList(e.Item.Text);
                    BindToMaboutDataSet();
                }
                populatelistview();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "!!");
                flag = false;
                if (e.Item.CheckState == Telerik.WinControls.Enumerations.ToggleState.Off) e.Item.CheckState = Telerik.WinControls.Enumerations.ToggleState.On;
                else e.Item.CheckState = Telerik.WinControls.Enumerations.ToggleState.Off;
                flag = true;
                populatelistview();
            }
        }
        void RemoveFromList(String txt)
        {
            foreach (ListViewDataItem listViewDataItem in radListView1.Items)
                if (listViewDataItem.Text == txt) radListView1.Items.Remove(listViewDataItem);
        }
        int generateSerial()
        {
            InvworldDB invworldDB = new InvworldDB();
            int Serial = System.Convert.ToInt32(serialNo.ToString());
            int lastSer = 0;
            if (invworldDB.GetInvworldItemList().Count() > 0)
                lastSer = invworldDB.GetInvworldItemList().Max(x => x.Ser);
            return lastSer + 1;
        }
        private void BindToMaboutDataSet()
        {
            this.radGridView1.MasterTemplate.AutoGenerateColumns = true;
            this.radGridView1.DataSource = new InvworldDB().GetInvworldListByID(System.Convert.ToInt32(serialNo));
            this.radGridView1.Columns["SERIAL"].HeaderText = "المتسلسل";
            this.radGridView1.Columns["SER"].HeaderText = "رقم التصنيف";
            this.radGridView1.Columns["CODE"].HeaderText = "الرمز";
        }
        private void radCheckedListBox1_SelectedItemChanged(object sender, EventArgs e)
        {

        }

        private void radButton1_Click(object sender, EventArgs e)
        {
            try
            {
                InvworldDB myInvworldDB = new InvworldDB();
                var idserial = (int)radGridView1.SelectedRows[0].Cells["SERIAL"].Value;
                var idsermon = (int)radGridView1.SelectedRows[0].Cells["SER"].Value;
                int code = myInvworldDB.GetInvworldByIDAndSerial(idserial, idsermon).Code;
                myInvworldDB.RemoveWord(idserial, idsermon);
                flag = false;
                for (int i = 0; i < radCheckedListBox1.Items.Count; i++)
                    if (Convert.ToInt32(radCheckedListBox1.Items[i].Value.ToString()) == code)
                        radCheckedListBox1.Items[i].CheckState = Telerik.WinControls.Enumerations.ToggleState.Off;
                populatelistview();
                BindToMaboutDataSet();
                MessageBox.Show(code.ToString());
                flag = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("No item selected");
            }
        }
    }
}

