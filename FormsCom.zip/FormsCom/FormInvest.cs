﻿//telet sura

using AppSec.Repositorys.Models;
using AppSec.Repositorys;
using AppSec.Repositorys.Helpers;
using AppSec.Repositorys.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Shell;
using Telerik.WinControls;
using Telerik.WinControls.UI;
using Telerik.Windows.Documents.Media;
using Telerik.Windows.Documents.Model.Drawing.Charts;
using Telerik.WinControls.Data;
using Telerik.Windows.Documents.Spreadsheet.Expressions.Functions;
using static System.Net.Mime.MediaTypeNames;

namespace AppSec.Forms
{
    public partial class FormInvest : Form
    {
        Investing newinvest;
        InvestingDB newinvestdb;
        private bool hasTextBeenTyped;
        private string serialNo = 1.ToString();
        private int intserialNo = 1;

        public string SerialNo
        {
            get { return serialNo; }
            set { serialNo = value; }
        }
        #region "Constructores"
        public FormInvest()
        {
            InitializeComponent();
        }
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            BindToInvestDataSet();
            this.populatedropdowncrime();//ok//ok
            this.DFDateTimePicker.Value = DateTime.Now;
            this.DMDateTimePicker.Value = DateTime.Now;
            this.cancelbtn.Click += new System.EventHandler(this.cancelbtn_Click);
            this.remtxtbx.Click += new System.EventHandler(this.remtxtbx_Click);
            this.newCrimetxbx.Click += new System.EventHandler(this.newCrimetxbx_Click);
            this.crimeDropDownList.SelectedIndexChanged += new Telerik.WinControls.UI.Data.PositionChangedEventHandler(this.crimeDropDownList_SelectedIndexChanged);
            this.radGridView1.CurrentRowChanged += new Telerik.WinControls.UI.CurrentRowChangedEventHandler(this.radGridView1_CurrentRowChanged);
            this.radGridView1.RowsChanging += new GridViewCollectionChangingEventHandler(radGridView1_RowsChanging);
            this.radGridView1.DefaultValuesNeeded += new GridViewRowEventHandler(radGridView1_DefaultValuesNeeded);
        }


        //Drop Down Lists Crime
        private void crimeDropDownList_SelectedIndexChanged(object sender, Telerik.WinControls.UI.Data.PositionChangedEventArgs e)
        {
            // Check if a valid item is selected (not the first item or -1)
            if (!this.crimeDropDownList.SelectedIndex.Equals(0) && !this.crimeDropDownList.SelectedIndex.Equals(-1))
            {
                this.newCrimetxbx.Text = String.Empty;
                int selectedIndex = this.crimeDropDownList.SelectedIndex;
                string selectedText = this.crimeDropDownList.SelectedItem.Text.ToString();
                DialogResult res = MessageBox.Show(selectedIndex.ToString() + "\n" + selectedText,
                                                   "Confirmation",
                                                   MessageBoxButtons.OKCancel,
                                                   MessageBoxIcon.Information);

                if (res == DialogResult.OK)
                {
                }
                else if (res == DialogResult.Cancel)
                {
                    // User clicked Cancel
                    MessageBox.Show("لقد قمت بالنقر فوق زر \"إلغاء الأمر\".", "Cancellation", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.newCrimetxbx.NullText = "[ادخال جرم جديد]"; // Set placeholder text for empty textbox
                }
            }
        }

        bool verify()
        {
            if (remtxtbx.Text.Length == 0)
            {
                MessageBox.Show("ادخال الموضوع");
                return false;
            }
            return true;
        }
        private void BindToInvestDataSet()
        {
            // Configure RadGridView1 for data display and interaction
            // 1. Set AutoSizeColumnsMode to Fill:
            this.radGridView1.MasterTemplate.AutoSizeColumnsMode = GridViewAutoSizeColumnsMode.Fill;
            //   - This ensures columns automatically resize to fill the available grid width.
            // 2. Optionally enable AutoGenerateColumns (default: false):
            //   - If your data source schema is unknown at design time, set this to true.
            //   - It will automatically create columns based on data source properties.
            // this.radGridView1.MasterTemplate.AutoGenerateColumns = true; // Optional
            // 3. BestFit columns to header cells:
            this.radGridView1.BestFitColumns(Telerik.WinControls.UI.BestFitColumnMode.HeaderCells);
            //   - This adjusts column widths to best fit their header text.
            // 4. Set data source:
            radGridView1.DataSource = new InvestingDB().GetInvestingItemList();
            //   - Binds the grid to data from the `GetInvestingItemList` method.
            // 5. Set column headers (assuming data source property names match):
            radGridView1.Columns["SERIAL"].HeaderText = "المتسلسل";
            radGridView1.Columns["DFILE"].HeaderText = "تأريخ المعامله";
            radGridView1.Columns["DMAHDAR"].HeaderText = "تأريخ الإدخال";
            radGridView1.Columns["CRIME"].HeaderText = "الجرم";
            radGridView1.Columns["MADBOUT"].HeaderText = "مضبوطات";
            radGridView1.Columns["RESUME"].HeaderText = "ملخص";
            radGridView1.Columns["REM"].HeaderText = "الموضوع";
            // 6. Set equal width for the first 7 columns:
            for (int i = 0; i < 7; i++)
            {
                radGridView1.Columns[i].Width = radGridView1.Width / 7;
            }
            //   - Ensures a consistent initial width distribution.
            // 7. Set right alignment for all cells:
            foreach (GridViewDataColumn column in radGridView1.Columns)
            {
                column.TextAlignment = ContentAlignment.MiddleRight;
            }
            //   - Aligns content to the right within each cell.
            // 8. Enable sorting for all columns:
            foreach (var column in radGridView1.MasterTemplate.Columns)
            {
                column.AllowSort = true;
            }
            //   - Allows users to sort data by clicking column headers.
            // 9. Initialize `intserialNo` variable (assuming its purpose is outside this code):
            intserialNo = 0;
        }


        private void radGridView1_RowsChanging(object sender, GridViewCollectionChangingEventArgs e)
        {
            if (e.Action == Telerik.WinControls.Data.NotifyCollectionChangedAction.Remove)
            {
                DialogResult dialogResult = MessageBox.Show("Do you want to delete this product?", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                if (dialogResult != DialogResult.OK)
                {
                    e.Cancel = true;
                }
            }
        }
        // Event handler for when the current row changes in the grid view
        private void radGridView1_CurrentRowChanged(object sender, CurrentRowChangedEventArgs e)
        {
            try
            {
                // Instantiate an Office object
                Office noffice = new Office();
                // Reset the dropdown form
                ResetDDform();
                // Get the Investing object associated with the current row
                Investing myinvest = (Investing)radGridView1.CurrentRow.DataBoundItem;

                // Check if the Investing object is not null
                if (myinvest != null)
                {
                    // Set values from the Investing object to various controls
                    serialNo = myinvest.Serial.ToString();
                    this.radLabelSerial.Text = myinvest.Serial.ToString();
                    this.DFDateTimePicker.Value = myinvest.Dfile;
                    this.DMDateTimePicker.Value = myinvest.Dmahdar;
                    this.newCrimetxbx.Text = myinvest.Crime.ToString();
                    // Check if Madbout flag is "y" and set the corresponding checkbox
                    // Set checkbox states based on Investing object properties
                    this.radCheckBox1.Checked = myinvest.Madbout == "y";
                    this.radCheckBox2.Checked = myinvest.Resume == "y";
                    this.remtxtbx.Text = myinvest.Rem.ToString();
                    // Display a message box with selected data
                    String datatext = " [المتسلسل] " + serialNo + "\n";
                    DialogResult res = MessageBox.Show(" [selected] " + datatext, "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                    // Handle the result of the message box
                    if (res == DialogResult.OK)
                    {
                        // Perform tasks if the user clicks OK
                        // For example:
                        // MessageBox.Show("You have clicked Ok Button");
                    }
                    else if (res == DialogResult.Cancel)
                    {

                    }
                }
            }
            catch (Exception)
            {
                // Catch any exceptions and return
                return;
            }
        }

        private void radGridView1_DefaultValuesNeeded(object sender, GridViewRowEventArgs e)
        {

        }
        private void populatetypeDropDownList()
        {
            List<String> typelist = new List<string>();
            typelist.Add("[نوع المحضر]");
            typelist.Add("مسلكي");
            typelist.Add("جزائي");
            ListToDataTable listToDataTable = new ListToDataTable();
            DataTable dataTable = listToDataTable.listTodatatable(typelist, "hggffdds");

        }
        private void populatejuryDropDownList()
        {

        }
        private void populateiresDropDownList()
        {
            List<String> ireslist = new List<string>();
            ireslist.Add("[مصير التحقيق]");
            ireslist.Add("سلبي");
            ireslist.Add("ايجابي");
            ireslist.Add("قيد المتابعه");
            ireslist.Add("إقفال الملف");
            ireslist.Add("محاله");
            ireslist.Add("مقضية");
            ListToDataTable listToDataTable = new ListToDataTable();
            DataTable dataTable = listToDataTable.listTodatatable(ireslist, "[ireslist]");
        }
        private void populatekproDropDownList()
        {
        }
        private void populatekaccuDropDownList()
        {
        }
        private void populateoffficedropdownlist()
        {
            var db = new SecEntities();
            DataTable officestb = db.DataTable("SELECT * FROM [dbo].[office]");
        }
        private void populatedropdowncrime()
        {
            var db = new SecEntities();
            DataTable newofficestb;
            try
            {
                newofficestb = db.DataTable("SELECT Distinct CRIME FROM [dbo].[INVESTING]");
                this.crimeDropDownList.ValueMember = "CRIME";
                this.crimeDropDownList.DisplayMember = "CRIME";
                this.crimeDropDownList.DataSource = newofficestb;
                this.crimeDropDownList.SelectedItem.Index.Equals(0);

                // rest of your code
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void populatedropdownprocureur()
        {
        }
        #endregion

        #region "Definición de Métodos"
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
        }
        #endregion

        #region "Métodos de Eventos"
        private void FormOrder_Load(object sender, EventArgs e)
        {
        }
        #endregion
        private void insertbtn_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("[سيتم ادخال المعلومات]", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            if (res == DialogResult.OK)
            {
                newinvest = new Investing();
                newinvestdb = new InvestingDB();
                var db = new SecEntities();
                int lastSerial = db.Investings.Max(x => x.Serial);
                if (verify())
                {
                    newinvest.Serial = lastSerial + 1;
                    newinvest.Dfile = this.DFDateTimePicker.Value;
                    newinvest.Dmahdar = this.DMDateTimePicker.Value;
                    newinvest.Crime = this.newCrimetxbx.Text.ToString();
                    if (this.radCheckBox1.Checked == true) { this.newinvest.Madbout = "y"; } else { newinvest.Madbout = "n"; }
                    if (this.radCheckBox2.Checked == true) { this.newinvest.Resume = "y"; } else { newinvest.Resume = "n"; }
                    newinvest.Rem = this.remtxtbx.Text.ToString();
                    newinvestdb.AddNew(newinvest);
                    BindToInvestDataSet();
                }
                //}
                if (res == DialogResult.Cancel)
                {
                    AutoClosingMessageBox.Show("لقد قمت بالنقر فوق زر الإلغاءn", timeout: 5000, showCountDown: true);
                }

            }
            Resetform();
        }

        private void editbtn_Click(object sender, EventArgs e)
        {

            //else if ((!string.IsNullOrEmpty(this.Mahdar.Text) && this.Mahdar.Text != "[محضر رقم]"))
            //{
            String datatext = "المتسلسل" + System.Convert.ToInt32(this.radLabelSerial.Text.ToString()) + "\n";// +
            DialogResult res = MessageBox.Show("[سيتم ادخال المعلومات]" + "\n" + datatext, "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (res == DialogResult.OK)
            {
                this.newinvest = new Investing();
                newinvestdb = new InvestingDB();
                var db = new SecEntities();
                int countrows = db.Investings.ToList().Count;
                this.newinvest.Serial = System.Convert.ToInt32(this.radLabelSerial.Text.ToString());
                this.newinvest.Dfile = this.DFDateTimePicker.Value;
                this.newinvest.Dmahdar = this.DMDateTimePicker.Value;
                this.newinvest.Crime = this.newCrimetxbx.Text.ToString();
                if (this.radCheckBox1.Checked == true) { this.newinvest.Madbout = "y"; } else { newinvest.Madbout = "n"; }
                if (this.radCheckBox2.Checked == true) { this.newinvest.Resume = "y"; } else { newinvest.Resume = "n"; }
                newinvest.Rem = this.remtxtbx.Text.ToString();
                newinvestdb.Update(newinvest);
                BindToInvestDataSet();
            }
            if (res == DialogResult.Cancel)
            {
                MessageBox.Show("تم الغاءالعمليه");
            }
        }



        private void deletebtn_Click(object sender, EventArgs e)
        {
            try
            {
                //newinvest = new Invest();
                newinvestdb = new InvestingDB();
                InvmadDB invmadDB = new InvmadDB();
                InvmonyDB invmonyDB = new InvmonyDB();
                InvpersonDB invpersonDB = new InvpersonDB();
                InvreDB invre = new InvreDB();
                InvarstDB invarstDB = new InvarstDB();
                ImageFaceDB imageFaceDB = new ImageFaceDB();
                ImageFpDB imageFpDB = new ImageFpDB();
                var context = new SecEntities();
                var ctxAtrr = new SecEntities();
                var ctxInvperson = new SecEntities();
                var ctxImages = new SecEntities();
                var ctxVehicles = new SecEntities();
                //var db = new SecEntities();
                var id = (int)radGridView1.SelectedRows[0].Cells["SERIAL"].Value;
                newinvestdb.Remove(id);
                var listMad = context.Invmads.Where(p => p.Serial == id).ToList();
                context.Invmads.RemoveRange(listMad);
                context.SaveChanges();
                var listMoney = context.Invmonies.Where(p => p.Serial == id).ToList();
                context.Invmonies.RemoveRange(listMoney);
                context.SaveChanges();
                var listPersons = ctxInvperson.Invpersons.Where(p => p.Serial == id).ToList();
                ctxInvperson.Invpersons.RemoveRange(listPersons);
                ctxInvperson.SaveChanges();
                var listRes = context.Invres.Where(p => p.Serial == id).ToList();
                context.Invres.RemoveRange(listRes);
                context.SaveChanges();
                var listVarst = context.Invarsts.Where(p => p.Serial == id).ToList();
                context.Invarsts.RemoveRange(listVarst);
                context.SaveChanges();
                var listImages = ctxImages.ImageFaces.Where(p => p.Serial == id).ToList();
                ctxImages.ImageFaces.RemoveRange(listImages);
                ctxImages.SaveChanges();
                var listFingerPrints = ctxImages.ImageFps.Where(p => p.Serial == id).ToList();
                ctxImages.ImageFps.RemoveRange(listFingerPrints);
                ctxImages.SaveChanges();
                var listBallistics = ctxVehicles.BallisticItems.Where(p => p.BallisticserialNo == id.ToString());
                ctxVehicles.BallisticItems.RemoveRange(listBallistics);
                ctxImages.SaveChanges();
                var listVehicles = ctxVehicles.Vehicles.Where(p => p.SerialNb == id).ToList();
                ctxVehicles.RemoveRange(listVehicles);
                ctxVehicles.SaveChanges();
                var listWord = context.Invworlds.Where(p => p.Serial == id).ToList();
                context.RemoveRange(listWord);
                context.SaveChanges();
                intserialNo = 0;
                Resetform();
            }
            catch (Exception ex)
            {
                MessageBox.Show("You must select an item");
            }
        }

        private void newbtn_Click(object sender, EventArgs e)
        {
            BindToInvestDataSet();
        }

        private void cancelbtn_Click(object sender, EventArgs e)
        {
            Resetform();
        }

        private void Resetform()
        {
            //this.crimeDropDownList.SelectedIndex = 0;
            this.radCheckBox1.Checked = false;
            this.radCheckBox2.Checked = false;
            this.newCrimetxbx.Text = "[ادخال جرم جديد]";
            this.remtxtbx.Text = "[موضوع المحضر]";
            this.DFDateTimePicker.Value = DateTime.Now;
            this.DMDateTimePicker.Value = DateTime.Now;
            // BindToInvestDataSet();
        }
        private void ResetDDform()
        {


        }

        private void Mahdar_TextChanged(object sender, EventArgs e)
        {
            //if (this.Mahdar.Text == "[محضر رقم]")
            //    this.Mahdar.Text = String.Empty;
        }
        private void Mahdar_Click(object sender, EventArgs e)
        {
        }

        private void newCrimetxbx_Click(object sender, EventArgs e)
        {
        }
        private void proctxbx_Click(object sender, EventArgs e)
        {
        }
        private void judge_Click(object sender, EventArgs e)
        {
        }
        private void Accuse_Click(object sender, EventArgs e)
        {
            //if (this.Accuse.Text == "[المدعى عليه]")
            //    this.Accuse.Text = String.Empty;
        }
        private void generaltxtbx_Click(object sender, EventArgs e)
        {
        }
        private void remtxtbx_Click(object sender, EventArgs e)
        {
        }
        //private void Nfile_TextChanged(object sender, EventArgs e)
        //{
        //}
        private void Nfile_Click(object sender, EventArgs e)
        {

        }

        private void Madbout_Click(object sender, EventArgs e)
        {
        }

        private void InvPers_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(serialNo))
            {
                FormInvpers2 fm = new FormInvpers2(this);
                fm.Show();
            }
            else
            {
                DialogResult res = MessageBox.Show("الرقم التسلسلي المحدد فارغ أو فارغ، اختر صفًا في الشبكة");
                if (res == DialogResult.OK)
                {
                    MessageBox.Show("لقد قمت بالنقر فوق زر موافق");
                }
                if (res == DialogResult.Cancel)
                {
                    MessageBox.Show("You have clicked Cancel Button");
                }
            }
        }

        private void InvRes_Click(object sender, EventArgs e)
        {
        }
        private void mony_Click(object sender, EventArgs e)
        {
        }
        private void arrest_Click(object sender, EventArgs e)
        {
        }
        private void resm_Click(object sender, EventArgs e)
        {
        }
        private void word_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(serialNo))
            {
                FormWord2 fm = new FormWord2(this);
                fm.Show();
            }
            else
            {
                DialogResult res = MessageBox.Show("serialNo is null or empty choose a row in the grid");
                if (res == DialogResult.OK)
                {
                    MessageBox.Show("You have clicked Ok Button");
                }
                if (res == DialogResult.Cancel)
                {
                    MessageBox.Show("You have clicked Cancel Button");
                }
            }
        }

        private void newCrimetxbx_TextChanged(object sender, EventArgs e)
        {
            if (this.newCrimetxbx.Text == "[ادخال جرم جديد]")
                this.newCrimetxbx.Text = string.Empty;
        }



        private void remtxtbx_TextChanged(object sender, EventArgs e)
        {
            if (this.remtxtbx.Text == "[موضوع المحضر]")
                this.remtxtbx.Text = string.Empty;
        }


        private void radButtonvehl_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(serialNo))
            {
                FormVehicles fm = new FormVehicles(int.Parse(serialNo));
                fm.Show();
            }
            else
            {
                DialogResult res = MessageBox.Show("serialNo is null or empty choose a row in the grid");
                if (res == DialogResult.OK)
                {
                    MessageBox.Show("You have clicked Ok Button");
                }
                if (res == DialogResult.Cancel)
                {
                    MessageBox.Show("You have clicked Cancel Button");
                }
            }
        }
    }
}
