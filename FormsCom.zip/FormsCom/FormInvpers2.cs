﻿//hayda tene sura ba3atta


using AppSec.Repositorys;
using AppSec.Repositorys.Helpers;
using AppSec.Repositorys.Models;
using AppSec.Repositorys.Utils;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Telerik.WinControls.UI;

namespace AppSec.Forms
{
    public partial class FormInvpers2 : Form
    {
        //Invest newinvest;
        Invperson myinper;
        InvpersonDB myinvperDB;
        private string serialNo;
        private int intserialNo;
        private FormInvest fi = null;
        public string SerialNo
        {
            get { return serialNo; }
            set { serialNo = value; }
        }
        #region "Constructores"
        public FormInvpers2()
        {
            InitializeComponent();
        }
        public FormInvpers2(Form CallingForm)
        {
            fi = CallingForm as FormInvest;
            InitializeComponent();
            serialNo = fi.SerialNo;
            intserialNo = Convert.ToInt32(serialNo);
            Debug.Print("fi.SerialNo", fi.SerialNo);
            this.Serialtxbx.Text = serialNo;
        }
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            BindToInvpersDataSet();
            this.ResidDDL.SelectedIndexChanged += new Telerik.WinControls.UI.Data.PositionChangedEventHandler(this.ResidDDL_SelectedIndexChanged);
            this.PbirthDDL.SelectedIndexChanged += new Telerik.WinControls.UI.Data.PositionChangedEventHandler(this.PbirthDDL_SelectedIndexChanged);
            this.NationDDL.SelectedIndexChanged += new Telerik.WinControls.UI.Data.PositionChangedEventHandler(this.NationDDL_SelectedIndexChanged);
            this.attrDDL.SelectedIndexChanged += new Telerik.WinControls.UI.Data.PositionChangedEventHandler(this.attrDDL_SelectedIndexChanged);
            this.Fname.Click += new System.EventHandler(this.Fname_Click);
            this.Father.Click += new System.EventHandler(this.Father_Click);
            this.Lname.Click += new System.EventHandler(this.Lname_Click);
            this.Mother.Click += new System.EventHandler(this.Mother_Click);
            this.Pbirth.Click += new System.EventHandler(this.Pbirth_Click);
            this.Resid.Click += new System.EventHandler(this.Resid_Click);
            this.Dbirth.Click += new System.EventHandler(this.Dbirth_Click);
            this.arch.Click += new System.EventHandler(this.arch_Click);
            this.reg.Click += new System.EventHandler(this.reg_Click);
            this.radGridView1.CurrentRowChanged += new Telerik.WinControls.UI.CurrentRowChangedEventHandler(this.radGridView1_CurrentRowChanged);
            this.radGridView1.RowsChanging += new GridViewCollectionChangingEventHandler(radGridView1_RowsChanging);
            this.populateattrDDL();
            this.populateNationDDL();
            this.populatePbirthDDL();
            this.populateResidDDL();
        }

        private void radGridView1_RowsChanging(object sender, GridViewCollectionChangingEventArgs e)
        {
            throw new NotImplementedException();
        }

        private void radGridView1_CurrentRowChanged(object sender, CurrentRowChangedEventArgs e)
        {
            try
            {
                Invperson myinvper = (Invperson)radGridView1.CurrentRow.DataBoundItem;
                if (myinvper != null)
                {
                    //myinper.Serial = intserialNo;
                    //myinper.Serpers = myinvperDB.GetInvperListByID(myinper.Serial).Count() + 1;
                    this.serperstxbx.Text = myinvper.Serpers.ToString();
                    this.Serialtxbx.Text = myinvper.Serial.ToString();
                    this.Fname.Text = myinvper.Fname.ToString();
                    this.Lname.Text = myinvper.Lname.ToString();
                    this.Father.Text = myinvper.Father.ToString();
                    this.Mother.Text = myinvper.Mother.ToString();
                    this.Dbirth.Text = myinvper.Dbirth.ToString();
                    this.Resid.Text = myinvper.Resid.ToString();
                    this.Pbirth.Text = myinvper.Pbirth.ToString();
                    this.reg.Text = myinvper.Reg.ToString();
                    if (myinvper.Adrs == "y") { this.Adrs.Checked = true; }
                    else { this.Adrs.Checked = false; };
                    if (myinvper.Exst == 1) { this.Exist.Checked = true; }
                    else { this.Exist.Checked = false; };
                    this.arch.Text = myinvper.Arch.ToString();
                    this.populatePbirthDDL();
                    this.populateResidDDL();
                    this.attrDDL.SelectedIndex = (int)myinvper.Attr;
                    this.NationDDL.SelectedIndex = (int)myinvper.Nation;
                    this.radDropDownList2.SelectedIndex = int.Parse(myinvper.Status);
                    this.radDropDownList1.SelectedIndex = int.Parse(myinvper.Gender);
                    this.radNICKNAMETextBox.Text = myinvper.Nickname;
                    this.rMobileNo.Text = myinvper.Mobileno;
                    this.radMaskedEditBox1.Text = myinvper.Idnum;
                    this.radOCCUPATIONTextBox.Text = myinvper.Occupation;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }

        private void BindToInvpersDataSet()
        {
            this.radGridView1.MasterTemplate.AutoGenerateColumns = true;
            this.radGridView1.BestFitColumns();// = true;

            this.radGridView1.MasterTemplate.AutoGenerateColumns = true;
            this.radGridView1.DataSource = new InvpersonDB().GetPerscharsListByID(Convert.ToInt32(serialNo));

            this.radGridView1.Columns["SERIAL"].Width = 50;
            this.radGridView1.Columns["SERPERS"].Width = 50;
            this.radGridView1.Columns["SERIAL"].HeaderText = "[الرقم المتسلسل للملف]";
            this.radGridView1.Columns["SERPERS"].HeaderText = "[الرقم المتسلسل للشخص]";
            this.radGridView1.Columns["FNAME"].HeaderText = "[الإسم]";
            this.radGridView1.Columns["LNAME"].HeaderText = "[الشهرة]";
            this.radGridView1.Columns["FATHER"].HeaderText = "[إسم اللأب]";
            this.radGridView1.Columns["MOTHER"].HeaderText = "[إسم الأم]";
            this.radGridView1.Columns["NATION"].HeaderText = "[الجنسية]";
            this.radGridView1.Columns["REG"].HeaderText = "[سجل القيد]";
            this.radGridView1.Columns["PBIRTH"].HeaderText = "[محل الولادة]";
            this.radGridView1.Columns["DBIRTH"].HeaderText = "[تأريخ الولادة]";
            this.radGridView1.Columns["RESID"].HeaderText = "[محل السكن]";
            this.radGridView1.Columns["ADRS"].HeaderText = "[عنوان السكن]";
            this.radGridView1.Columns["ATTR"].HeaderText = "[إسم اللأب]";
            this.radGridView1.Columns["EXST"].HeaderText = "[هل يوجد رقم في الداخلي]";
            this.radGridView1.Columns["ARCH"].HeaderText = "[الرقم في الداخلي]";
            this.radGridView1.Columns["nickname"].HeaderText = "[اللقب]";
            this.radGridView1.Columns["occupation"].HeaderText = "[المهنة]";
            this.radGridView1.Columns["idnum"].HeaderText = "[رقم الهوية]";
            this.radGridView1.Columns["mobileno"].HeaderText = "[رقم الهاتف]";
            this.radGridView1.Columns["status"].HeaderText = "[الحالة الاجتماعية]";
            this.radGridView1.Columns["gender"].HeaderText = "[الجنس]";
        }
        #endregion

        #region "Definición de Métodos"
        private void LoadTheme()
        {
            foreach (Control btns in this.Controls)
            {
                if (btns.GetType() == typeof(Button))
                {
                    Button btn = (Button)btns;
                    btn.BackColor = ThemeColor.PrimaryColor;
                    btn.ForeColor = Color.White;
                    btn.FlatAppearance.BorderColor = ThemeColor.SecondaryColor;
                }
            }
            //label1.ForeColor = ThemeColor.SecondaryColor;
            //label5.ForeColor = ThemeColor.PrimaryColor;
        }
        #endregion

        #region "Métodos de Eventos"
        private void FormCustomer_Load(object sender, EventArgs e)
        {
            LoadTheme();
        }
        #endregion

        private void Insert_Click(object sender, EventArgs e)
        {
            if ((!string.IsNullOrEmpty(this.intserialNo.ToString())))
            {
                DialogResult res = MessageBox.Show("[سيتم ادخال المعلومات]", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                if (res == DialogResult.OK)
                {
                    MessageBox.Show("[موافقة]");
                    var db = new SecEntities();
                    myinper = new Invperson();
                    myinvperDB = new InvpersonDB();
                    this.myinper.Serial = intserialNo;
                    // this.myinper.Serpers = myinvperDB.GetInvperListByID(myinper.Serial).Count() + 1;
                    int lastPers = 0;
                    if (myinvperDB.GetPerscharsListByID(intserialNo).Count() != 0)
                        lastPers = myinvperDB.GetPerscharsListByID(this.intserialNo).Max(x => x.Serpers);

                    //  this.myinper.Serpers = myinvperDB.GetInvperListByID(myinper.Serial).Count() + 1;
                    this.myinper.Serpers = lastPers + 1;
                    if (verify())
                    {
                        this.myinper.Fname = this.Fname.Text.ToString();
                        this.myinper.Lname = this.Lname.Text.ToString();
                        this.myinper.Father = this.Father.Text.ToString();
                        this.myinper.Mother = this.Mother.Text.ToString();
                        if (!string.IsNullOrEmpty(this.Dbirth.Text))
                        {
                            this.myinper.Dbirth = Convert.ToInt32(this.Dbirth.Text);
                        }
                        else
                        {
                            this.myinper.Dbirth = 0;
                        }
                        this.myinper.Nation = this.NationDDL.SelectedIndex;
                        this.myinper.Resid = this.Resid.Text.ToString();
                        this.myinper.Pbirth = this.Pbirth.Text.ToString();
                        this.myinper.Attr = this.attrDDL.SelectedIndex;
                        this.myinper.Reg = this.reg.Text.ToString();
                        if (this.Adrs.Checked == true) { this.myinper.Adrs = "y"; } else { this.myinper.Adrs = "n"; }
                        if (this.Exist.Checked == true) { this.myinper.Exst = 1; } else { this.myinper.Exst = 0; }
                        this.myinper.Arch = Convert.ToInt32(this.arch.Text.ToString());
                        this.myinper.Nickname = this.radNICKNAMETextBox.Text;
                        this.myinper.Occupation = radOCCUPATIONTextBox.Text;
                        this.myinper.Idnum = radMaskedEditBox1.Text;
                        this.myinper.Mobileno = rMobileNo.Text;
                        this.myinper.Status = radDropDownList1.SelectedIndex.ToString();
                        this.myinper.Gender = radDropDownList2.SelectedIndex.ToString();
                        myinvperDB.AddNew(myinper);

                        BindToInvpersDataSet();
                        Resetform();
                    }
                }
                if (res == DialogResult.Cancel)
                {
                    MessageBox.Show("You have clicked Cancel Button");
                    //Some task…
                }

            }

        }
        bool verify()
        {
            if (Fname.Text.Length == 0 && radNICKNAMETextBox.Text.Length == 0)
            {
                MessageBox.Show("ادخال الأسم او اللقب");
                return false;
            }
            //if (Lname.Text.Length == 0)
            //{
            //    MessageBox.Show("Last name required");
            //    return false;
            //}
            //if (Father.Text.Length == 0)
            //{
            //    MessageBox.Show("Father name required");
            //    return false;
            //}
            //if (Mother.Text.Length == 0)
            //{
            //    MessageBox.Show("Mother name required");
            //    return false;
            //}
            //if (reg.Text.Length == 0)
            //{
            //    MessageBox.Show("Register number required");
            //    return false;
            //}
            //if (Pbirth.Text.Length == 0)
            //{
            //    MessageBox.Show("Place of birth required");
            //    return false;
            //}
            //if (Resid.Text.Length == 0)
            //{
            //    MessageBox.Show("Residence required");
            //    return false;
            //}
            if (System.Text.RegularExpressions.Regex.IsMatch(reg.Text, "[^0-9]"))

            {
                MessageBox.Show("Register field must be numeric");
                return false;
            }
            if (radMaskedEditBox1.Text.Length == 0)

            {
                MessageBox.Show("ID number must be numeric");
                return false;
            }
            if (rMobileNo.Text.Length == 0)
            {
                MessageBox.Show("Mobile number required");
                return false;
            }
            if (System.Text.RegularExpressions.Regex.IsMatch(Dbirth.Text, "[^0-9]"))
            {
                MessageBox.Show("Year of birth must be numeric");
                return false;
            }
            return true;
        }

        private void NationDDL_SelectedIndexChanged(object sender, Telerik.WinControls.UI.Data.PositionChangedEventArgs e)
        {
        }
        private void PbirthDDL_SelectedIndexChanged(object sender, Telerik.WinControls.UI.Data.PositionChangedEventArgs e)
        {
            if (!this.PbirthDDL.SelectedIndex.Equals(0) && !this.PbirthDDL.SelectedIndex.Equals(-1))
            {
                this.Pbirth.Text = String.Empty;
                DialogResult res = MessageBox.Show(this.PbirthDDL.SelectedIndex.ToString() + "\n" + this.PbirthDDL.SelectedItem.Text.ToString(), "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (res == DialogResult.OK)
                {
                    MessageBox.Show("You have clicked Ok Button");
                    this.Pbirth.Text = this.PbirthDDL.SelectedValue.ToString();
                    //Some task…
                }
                if (res == DialogResult.Cancel)
                {
                    MessageBox.Show("You have clicked Cancel Button");
                    //Some task…
                    this.Pbirth.NullText = "[محل الولادة]";
                }
            }
        }
        private void ResidDDL_SelectedIndexChanged(object sender, Telerik.WinControls.UI.Data.PositionChangedEventArgs e)
        {
            if (!this.ResidDDL.SelectedIndex.Equals(0) && !this.ResidDDL.SelectedIndex.Equals(-1))
            {
                this.Resid.Text = String.Empty;
                DialogResult res = MessageBox.Show(this.ResidDDL.SelectedIndex.ToString() + "\n" + this.ResidDDL.SelectedItem.Text.ToString(), "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (res == DialogResult.OK)
                {
                    MessageBox.Show("You have clicked Ok Button");
                    this.Resid.Text = this.ResidDDL.SelectedValue.ToString();
                    //Some task…
                }
                if (res == DialogResult.Cancel)
                {
                    MessageBox.Show("You have clicked Cancel Button");
                    //Some task…
                    this.Resid.NullText = "[محل السكن]";
                }
            }

        }
        private void attrDDL_SelectedIndexChanged(object sender, Telerik.WinControls.UI.Data.PositionChangedEventArgs e)
        {
        }
        private void Resetform()
        {
            this.attrDDL.SelectedIndex = 0;
            this.NationDDL.SelectedIndex = 0;
            this.PbirthDDL.SelectedIndex = 0;
            this.ResidDDL.SelectedIndex = 0;
            this.radDropDownList1.SelectedIndex = 0;
            this.radDropDownList2.SelectedIndex = 0;
            this.Exist.Checked = false;
            this.Adrs.Checked = false;
            this.Fname.Text = "[الإسم]";
            this.Lname.Text = "[الشهرة]";
            this.Father.Text = "[إسم اللأب]";
            this.Mother.Text = "[إسم الأم]";
            this.reg.Text = "[رقم ومكان السجل]";
            this.Pbirth.Text = "[محل الولادة]";
            //this.Dbirth.Text = "[محل الإقامة]";
            this.Dbirth.Text = "[تأريخ الولادة]";
            this.myinper.Arch = 0;
            this.Resid.Text = string.Empty;
            this.Pbirth.Text = "[محل الولادة]";
            this.rMobileNo.Text = string.Empty;
            this.radMaskedEditBox1.Text = string.Empty;
            this.radNICKNAMETextBox.Text = string.Empty;
            this.radOCCUPATIONTextBox.Text = string.Empty;
            this.populateattrDDL();
            this.populateNationDDL();
            this.populatePbirthDDL();
            this.populateResidDDL();
            // BindToInvpersDataSet();
        }
        private void populateattrDDL()
        {
            var db = new SecEntities();
            DataTable attrtb = db.DataTable("SELECT * FROM [dbo].[ATTR]");
            this.attrDDL.DataSource = attrtb;
            this.attrDDL.ValueMember = "Code";
            this.attrDDL.DisplayMember = "LABEL";
        }
        private void populateResidDDL()
        {
            var db = new SecEntities();
            DataTable Residtb = db.DataTable("SELECT * FROM [dbo].[village]");
            this.ResidDDL.DataSource = Residtb;
            this.ResidDDL.ValueMember = "LABEL";
            this.ResidDDL.DisplayMember = "LABEL";
        }
        private void populatePbirthDDL()
        {
            var db = new SecEntities();
            DataTable Pbirthtb = db.DataTable("SELECT * FROM [dbo].[village]");
            this.PbirthDDL.DataSource = Pbirthtb;
            this.PbirthDDL.ValueMember = "LABEL";
            this.PbirthDDL.DisplayMember = "LABEL";
        }
        private void populateNationDDL()
        {
            var db = new SecEntities();
            DataTable Nationtb = db.DataTable("SELECT * FROM [dbo].[nations]");
            this.NationDDL.DataSource = Nationtb;
            this.NationDDL.ValueMember = "Code";
            this.NationDDL.DisplayMember = "ALABEL";
        }

        private void Fname_Click(object sender, EventArgs e)
        {
            if (this.Fname.Text == "[الإسم]")
                this.Fname.Text = String.Empty;
        }

        private void Father_Click(object sender, EventArgs e)
        {
            if (this.Father.Text == "[إسم اللأب]")
                this.Father.Text = String.Empty;
        }

        private void Lname_Click(object sender, EventArgs e)
        {
            if (this.Father.Text == "[الشهرة]")
                this.Father.Text = String.Empty;
        }

        private void Mother_Click(object sender, EventArgs e)
        {
            if (this.Mother.Text == "[إسم الأم]")
                this.Mother.Text = String.Empty;
        }

        private void Pbirth_Click(object sender, EventArgs e)
        {
            if (this.Pbirth.Text == "[محل الولادة]")
                this.Pbirth.Text = String.Empty;
        }
        private void Dbirth_Click(object sender, EventArgs e)
        {
            if (this.Dbirth.Text == "[تأريخ الولادة]")
                this.Dbirth.Text = String.Empty;
        }
        private void reg_Click(object sender, EventArgs e)
        {
            if (this.reg.Text == "[رقم ومكان السجل]")
                this.reg.Text = String.Empty;
        }

        private void arch_Click(object sender, EventArgs e)
        {
            if (this.arch.Text == "[الرقم في الداخلي]")
                this.arch.Text = String.Empty;
        }
        private void Resid_Click(object sender, EventArgs e)
        {
            if (this.Resid.Text == "[محل الإقامة]")
                this.Resid.Text = String.Empty;
        }

        private void Fname_TextChanged(object sender, EventArgs e)
        {
            if (this.Fname.Text == "[الإسم]")
                this.Fname.Text = String.Empty;
        }

        private void Lname_TextChanged(object sender, EventArgs e)
        {
            if (this.Lname.Text == "[الشهرة]")
                this.Lname.Text = String.Empty;
        }

        private void Father_TextChanged(object sender, EventArgs e)
        {
            if (this.Father.Text == "[إسم اللأب]")
                this.Father.Text = String.Empty;
        }

        private void Mother_TextChanged(object sender, EventArgs e)
        {
            if (this.Mother.Text == "[إسم الأم]")
                this.Mother.Text = String.Empty;
        }

        private void reg_TextChanged(object sender, EventArgs e)
        {
            if (this.reg.Text == "[رقم ومكان السجل]")
                this.reg.Text = String.Empty;
        }

        private void Pbirth_TextChanged(object sender, EventArgs e)
        {
            if (this.Pbirth.Text == "[محل الولادة]")
                this.Pbirth.Text = String.Empty;
        }

        private void Resid_TextChanged(object sender, EventArgs e)
        {

        }

        private void Dbirth_TextChanged(object sender, EventArgs e)
        {

            if (this.Dbirth.Text == "[تأريخ الولادة]")
                this.Dbirth.Text = String.Empty;
        }

        private void arch_TextChanged(object sender, EventArgs e)
        {
            if (this.arch.Text == "[الرقم في الداخلي]")
                this.arch.Text = String.Empty;
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            this.Resetform();
            //this.Fname.NullText = "[الإسم]";
            //this.Lname.NullText = "[الشهرة]";
            //this.Father.NullText = "[إسم اللأب]";
            //this.Mother.NullText = "[إسم الأم]";
            //this.reg.NullText = "[رقم ومكان السجل]";
            //this.Pbirth.NullText = "[محل الولادة]";
            //this.Dbirth.NullText = "[محل الإقامة]";
            //this.Dbirth.NullText = "[تأريخ الولادة]";
            //this.arch.NullText = "[الرقم في الداخلي]";
        }

        private void delete_Click(object sender, EventArgs e)
        {
            try
            {
                myinvperDB = new InvpersonDB();
                var idserial = (int)radGridView1.SelectedRows[0].Cells["SERIAL"].Value;
                var idserpers = (int)radGridView1.SelectedRows[0].Cells["SERPERS"].Value;
                myinvperDB.RemoveChars(idserial, idserpers);
                Resetform();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("You must select an item");
            }
        }

        private void update_Click(object sender, EventArgs e)
        {
            if ((!string.IsNullOrEmpty(this.intserialNo.ToString())))
            {
                DialogResult res = MessageBox.Show("[سيتم ادخال المعلومات]", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                if (res == DialogResult.OK)
                {
                    MessageBox.Show("[موافقة]");
                    var db = new SecEntities();
                    myinper = new Invperson();
                    myinvperDB = new InvpersonDB();
                    this.myinper.Serial = Convert.ToInt32(this.Serialtxbx.Text.ToString());
                    this.myinper.Serpers = Convert.ToInt32(this.serperstxbx.Text.ToString());
                    //this.myinper.Serpers = myinvperDB.GetInvperListByID(myinper.Serial).Count() + 1;
                    if (verify())
                    {
                        this.myinper.Fname = this.Fname.Text.ToString();
                        this.myinper.Lname = this.Lname.Text.ToString();
                        this.myinper.Father = this.Father.Text.ToString();
                        this.myinper.Mother = this.Mother.Text.ToString();
                        this.myinper.Dbirth = Convert.ToInt32(this.Dbirth.Text.ToString());
                        this.myinper.Nation = this.NationDDL.SelectedIndex;
                        this.myinper.Resid = this.Resid.Text.ToString();
                        this.myinper.Pbirth = this.Pbirth.Text.ToString();
                        this.myinper.Attr = this.attrDDL.SelectedIndex;
                        this.myinper.Reg = this.reg.Text.ToString();
                        if (this.Adrs.Checked == true) { this.myinper.Adrs = "y"; } else { this.myinper.Adrs = "n"; }
                        if (this.Exist.Checked == true) { this.myinper.Exst = 1; } else { this.myinper.Exst = 0; }
                        this.myinper.Arch = Convert.ToInt32(this.arch.Text.ToString());
                        this.myinper.Nickname = this.radNICKNAMETextBox.Text;
                        this.myinper.Occupation = this.radOCCUPATIONTextBox.Text;
                        this.myinper.Idnum = this.radMaskedEditBox1.Text;
                        this.myinper.Mobileno = this.rMobileNo.Text;
                        this.myinper.Status = radDropDownList2.SelectedIndex.ToString();
                        this.myinper.Gender = radDropDownList1.SelectedIndex.ToString();
                        myinvperDB.Update(myinper);
                        BindToInvpersDataSet();
                        Resetform();
                    }
                }
                if (res == DialogResult.Cancel)
                {
                    MessageBox.Show("You have clicked Cancel Button");
                    //Some task…
                }

            }
        }

        private void ResidDDL_SelectedIndexChanged_1(object sender, Telerik.WinControls.UI.Data.PositionChangedEventArgs e)
        {

        }

        private void radOCCUPATIONTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
