﻿namespace AppSec.Forms
{
    partial class FormWord2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition4 = new Telerik.WinControls.UI.TableViewDefinition();
            radCheckedListBox1 = new Telerik.WinControls.UI.RadCheckedListBox();
            radListView1 = new Telerik.WinControls.UI.RadListView();
            radGridView1 = new Telerik.WinControls.UI.RadGridView();
            radTextBox1 = new Telerik.WinControls.UI.RadTextBox();
            radButton1 = new Telerik.WinControls.UI.RadButton();
            materialBlueGreyTheme1 = new Telerik.WinControls.Themes.MaterialBlueGreyTheme();
            radLabelSerialMD = new Telerik.WinControls.UI.RadLabel();
            ((System.ComponentModel.ISupportInitialize)radCheckedListBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radListView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radGridView1.MasterTemplate).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radTextBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radButton1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabelSerialMD).BeginInit();
            SuspendLayout();
            // 
            // radCheckedListBox1
            // 
            radCheckedListBox1.GroupItemSize = new System.Drawing.Size(200, 28);
            radCheckedListBox1.ItemSize = new System.Drawing.Size(200, 28);
            radCheckedListBox1.Location = new System.Drawing.Point(12, 100);
            radCheckedListBox1.Name = "radCheckedListBox1";
            radCheckedListBox1.Size = new System.Drawing.Size(197, 284);
            radCheckedListBox1.TabIndex = 2;
            radCheckedListBox1.SelectedItemChanged += radCheckedListBox1_SelectedItemChanged;
            radCheckedListBox1.ItemCheckedChanged += radCheckedListBox1_ItemCheckedChanged;
            // 
            // radListView1
            // 
            radListView1.GroupItemSize = new System.Drawing.Size(200, 28);
            radListView1.ItemSize = new System.Drawing.Size(200, 28);
            radListView1.Location = new System.Drawing.Point(295, 100);
            radListView1.Name = "radListView1";
            radListView1.Size = new System.Drawing.Size(212, 284);
            radListView1.TabIndex = 3;
            // 
            // radGridView1
            // 
            radGridView1.Location = new System.Drawing.Point(584, 12);
            // 
            // 
            // 
            radGridView1.MasterTemplate.ViewDefinition = tableViewDefinition4;
            radGridView1.Name = "radGridView1";
            radGridView1.Size = new System.Drawing.Size(384, 261);
            radGridView1.TabIndex = 4;
            // 
            // radTextBox1
            // 
            radTextBox1.Location = new System.Drawing.Point(82, 41);
            radTextBox1.Name = "radTextBox1";
            radTextBox1.ReadOnly = true;
            radTextBox1.Size = new System.Drawing.Size(100, 24);
            radTextBox1.TabIndex = 5;
            // 
            // radButton1
            // 
            radButton1.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            radButton1.Location = new System.Drawing.Point(864, 398);
            radButton1.Name = "radButton1";
            radButton1.Size = new System.Drawing.Size(104, 40);
            radButton1.TabIndex = 7;
            radButton1.Text = "حذف";
            radButton1.Click += radButton1_Click;
            // 
            // radLabelSerialMD
            // 
            radLabelSerialMD.BackColor = System.Drawing.Color.White;
            radLabelSerialMD.Location = new System.Drawing.Point(82, 12);
            radLabelSerialMD.Name = "radLabelSerialMD";
            radLabelSerialMD.Size = new System.Drawing.Size(53, 21);
            radLabelSerialMD.TabIndex = 68;
            radLabelSerialMD.Text = "المتسلسل";
            radLabelSerialMD.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            radLabelSerialMD.ThemeName = "MaterialBlueGrey";
            // 
            // FormWord2
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1029, 450);
            Controls.Add(radLabelSerialMD);
            Controls.Add(radButton1);
            Controls.Add(radTextBox1);
            Controls.Add(radGridView1);
            Controls.Add(radListView1);
            Controls.Add(radCheckedListBox1);
            Name = "FormWord2";
            Text = "FormWord2";
            Load += FormWord2_Load;
            ((System.ComponentModel.ISupportInitialize)radCheckedListBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)radListView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)radGridView1.MasterTemplate).EndInit();
            ((System.ComponentModel.ISupportInitialize)radGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)radTextBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)radButton1).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabelSerialMD).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Telerik.WinControls.UI.RadCheckedListBox radCheckedListBox1;
        private Telerik.WinControls.UI.RadListView radListView1;
        private Telerik.WinControls.UI.RadGridView radGridView1;
        private Telerik.WinControls.UI.RadTextBox radTextBox1;
        private Telerik.WinControls.UI.RadButton radButton1;
        private Telerik.WinControls.Themes.MaterialBlueGreyTheme materialBlueGreyTheme1;
        private Telerik.WinControls.UI.RadLabel radLabelSerialMD;
    }
}