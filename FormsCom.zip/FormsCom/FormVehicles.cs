﻿//khames sura

using AppSec.Repositorys;
using AppSec.Repositorys.Helpers;
using AppSec.Repositorys.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Telerik.WinControls.UI;
using Telerik.WinControls.UI.Map.Bing;

namespace AppSec.Forms
{
    public partial class FormVehicles : Form
    {
        int serial;
        public FormVehicles()
        {
            InitializeComponent();
        }
        public FormVehicles(int ser)
        {
            InitializeComponent();
            serial = ser;
        }

        private void FormVehicles_Load(object sender, EventArgs e)
        {
            txtSerial.Text = serial.ToString();
            populatePbirthDDL(ddlBirthPlace);
            populatePbirthDDL(ddlCity);
            txtSerial.Text = serial.ToString();
            if (new VehiclesDB().GetVehiclesBySerial(serial).Count() == 0)
                txtVehicleId.Text = "No vehicles for the current invest";
            else txtVehicleId.Text = new VehiclesDB().GetVehiclesBySerial(serial).Count().ToString();
            popoulateToGridView();
        }
        private void populatePbirthDDL(RadDropDownList PbirthDDL)
        {
            var db = new SecEntities();
            DataTable Pbirthtb = db.DataTable("SELECT * FROM [dbo].[village]");
            PbirthDDL.DataSource = Pbirthtb;
            PbirthDDL.ValueMember = "LABEL";
            PbirthDDL.DisplayMember = "LABEL";
        }
        bool Verify()
        {
            if (txtNumber.Text.Length > 10)
            {
                MessageBox.Show("Plate Number must not exceed 10 digits");
                return false;
            }
            if (txtChassis.Text.Length == 0)
            {
                MessageBox.Show("Chassis required");
                return false;
            }
            if (txtMotor.Text.Length == 0)
            {
                MessageBox.Show("Motor required");
                return false;
            }
            if (txtColor.Text.Length == 0)
            {
                MessageBox.Show("Vehicle color required");
                return false;
            }
            if (txtBrand.Text.Length == 0)
            {
                MessageBox.Show("Vehicle brand required");
                return false;
            }
            if (txtModel.Text.Length == 0)
            {
                MessageBox.Show("Vehicle model required");
                return false;
            }
            if (txtDescription.Text.Length == 0)
            {
                MessageBox.Show("Vehicle description required");
                return false;
            }
            if (txtName.Text.Length == 0)
            {
                MessageBox.Show("Vehicle owner name required");
                return false;
            }
            if (txtLastName.Text.Length == 0)
            {
                MessageBox.Show("Vehicle owner last name required");
                return false;
            }
            if (txtRegNum.Text.Length == 0)
            {
                MessageBox.Show("Vehicle owner register number required");
                return false;
            }
            if (txtAddress.Text.Length == 0)
            {
                MessageBox.Show("Vehicle owner address required");
                return false;
            }
            if (txtDistrict.Text.Length == 0)
            {
                MessageBox.Show("Vehicle owner district required");
                return false;
            }
            if (telephone.Text.Length == 0)
            {
                MessageBox.Show("Vehicle owner telephone number required");
                return false;
            }
            return true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Vehicle vehicle = new Vehicle();
                vehicle.Vid = generateSerial();
                vehicle.SerialNb = serial;
                vehicle.ActualNb = txtNumber.Text;
                vehicle.CodeDesc = ddlCode.SelectedItem.ToString();
                vehicle.Proddate = dtpProductionDate.Value.ToString();
                vehicle.Chassis = txtChassis.Text;
                vehicle.Motor = txtMotor.Text;
                vehicle.Dateaquisition = dtpAquisitionDate.Value.ToString();
                vehicle.ColorDesc = txtColor.Text;
                vehicle.Brand = txtBrand.Text;
                vehicle.Model = txtModel.Text;
                vehicle.UtilisDesc = txtDescription.Text;
                vehicle.Name = txtName.Text;
                vehicle.Lastname = txtLastName.Text;
                vehicle.NoRegProp = txtRegNum.Text;
                vehicle.Address = txtAddress.Text;
                vehicle.CityId = ddlCity.SelectedItem.ToString();
                vehicle.DistrictId = txtDistrict.Text;
                vehicle.MotherName = txtMotherName.Text;
                vehicle.PreMiseCirc = nudFirstLaunch.Value.ToString();
                vehicle.TelProp = telephone.Text;
                vehicle.AgeProp = nudAge.Value.ToString();
                vehicle.BirthPlace = ddlBirthPlace.SelectedItem.ToString();
                if (radCheckBox1.Checked)
                    vehicle.Horsservice = 1;
                else vehicle.Horsservice = 0;
                if (Verify())
                    new VehiclesDB().AddNew(vehicle);
                else
                    MessageBox.Show("Failed to add new vehicle");
                popoulateToGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }

        }
        int generateSerial()
        {
            VehiclesDB db = new VehiclesDB();
            int lastser = 0;
            if (db.GetVehicleList().Count() > 0)
                lastser = db.GetVehicleList().Max(x => x.Vid);
            else lastser = 0;
            return lastser + 1;
        }
        void popoulateToGridView()
        {

            this.radGridView1.MasterTemplate.AutoGenerateColumns = true;
            this.radGridView1.BestFitColumns();// = true;
            this.radGridView1.MasterTemplate.AutoGenerateColumns = true;
            radGridView1.DataSource = new VehiclesDB().GetVehiclesBySerial(serial);
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Vehicle vehicle = new Vehicle();
                vehicle.Vid = int.Parse(txtVehicleId.Text);
                vehicle.SerialNb = serial;
                vehicle.ActualNb = txtNumber.Text;
                vehicle.CodeDesc = ddlCode.SelectedItem.ToString();
                vehicle.Proddate = dtpProductionDate.Value.ToString();
                vehicle.Chassis = txtChassis.Text;
                vehicle.Motor = txtMotor.Text;
                vehicle.Dateaquisition = dtpAquisitionDate.Value.ToString();
                vehicle.ColorDesc = txtColor.Text;
                vehicle.Brand = txtBrand.Text;
                vehicle.Model = txtModel.Text;
                vehicle.UtilisDesc = txtDescription.Text;
                vehicle.Name = txtName.Text;
                vehicle.Lastname = txtLastName.Text;
                vehicle.NoRegProp = txtRegNum.Text;
                vehicle.Address = txtAddress.Text;
                vehicle.CityId = ddlCity.SelectedItem.ToString();
                vehicle.DistrictId = txtDistrict.Text;
                vehicle.MotherName = txtMotherName.Text;
                vehicle.PreMiseCirc = nudFirstLaunch.Value.ToString();
                vehicle.TelProp = telephone.Text;
                vehicle.AgeProp = nudAge.Value.ToString();
                vehicle.BirthPlace = ddlBirthPlace.SelectedItem.ToString();
                if (radCheckBox1.Checked)
                    vehicle.Horsservice = 1;
                else vehicle.Horsservice = 0;
                if (Verify())
                {
                    new VehiclesDB().Update(vehicle);
                    popoulateToGridView();
                }
                else
                    MessageBox.Show("Failed to update vehicle");

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void radGridView1_CurrentRowChanged(object sender, CurrentRowChangedEventArgs e)
        {
            Vehicle vehicle = (Vehicle)radGridView1.CurrentRow.DataBoundItem;
            if (vehicle != null)
            {
                txtVehicleId.Text = vehicle.Vid.ToString();
                txtNumber.Text = vehicle.ActualNb;
                setDropDownListSelectedItem(ddlCode, vehicle.CodeDesc);
                dtpProductionDate.Value = DateTime.Parse(vehicle.Proddate);
                txtChassis.Text = vehicle.Chassis;
                txtMotor.Text = vehicle.Motor;
                dtpAquisitionDate.Value = DateTime.Parse(vehicle.Dateaquisition);
                txtColor.Text = vehicle.ColorDesc;
                txtBrand.Text = vehicle.Brand;
                txtModel.Text = vehicle.Model;
                txtDescription.Text = vehicle.UtilisDesc;
                txtName.Text = vehicle.Name;
                txtLastName.Text = vehicle.Lastname;
                txtRegNum.Text = vehicle.NoRegProp;
                txtAddress.Text = vehicle.Address;
                setDropDownListSelectedItem(ddlCity, vehicle.CityId);
                txtDistrict.Text = vehicle.DistrictId;
                txtMotherName.Text = vehicle.MotherName;
                telephone.Text = vehicle.TelProp;
                nudAge.Value = int.Parse(vehicle.AgeProp);
                setDropDownListSelectedItem(ddlBirthPlace, vehicle.BirthPlace);
                radCheckBox1.Checked = (vehicle.Horsservice == 1);
                nudFirstLaunch.Value = int.Parse(vehicle.PreMiseCirc);
            }
        }
        void setDropDownListSelectedItem(RadDropDownList ddl, string item)
        {
            for (int i = 0; i < ddl.Items.Count; i++)
                if (ddl.Items[i].Text == item)
                    ddl.SelectedIndex = i;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (radGridView1.Rows.Count > 0)
            {
                int vid = (int)radGridView1.SelectedRows[0].Cells[0].Value;
                new VehiclesDB().Remove(vid);
                popoulateToGridView();
            }
            else
                MessageBox.Show("No vehicles to remove");
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            foreach (Control ctrl in Controls)
            {
                if (ctrl.GetType() == typeof(RadTextBox))
                    if (ctrl.Name != "txtSerial" && ctrl.Name != "txtVehicleId")
                        ctrl.Text = string.Empty;
                if (ctrl.GetType() == typeof(RadMaskedEditBox))
                    ctrl.Text = string.Empty;

            }
            ddlBirthPlace.SelectedIndex = 0;
            ddlCity.SelectedIndex = 0;
            ddlCode.SelectedIndex = 0;
            dtpAquisitionDate.Value = DateTime.Now;
            dtpProductionDate.Value = DateTime.Now;
            nudAge.Value = nudAge.Minimum;
            nudFirstLaunch.Value = nudFirstLaunch.Minimum;
        }
    }
}
