﻿using Telerik.WinControls.UI;

namespace AppSec.Forms
{
    partial class FormInvest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            TableViewDefinition tableViewDefinition1 = new TableViewDefinition();
            DMDateTimePicker = new RadDateTimePicker();
            materialBlueGreyTheme1 = new Telerik.WinControls.Themes.MaterialBlueGreyTheme();
            insertbtn = new RadButton();
            editbtn = new RadButton();
            deletebtn = new RadButton();
            refreshbtn = new RadButton();
            radCheckBox1 = new RadCheckBox();
            radCheckBox2 = new RadCheckBox();
            remtxtbx = new RadTextBox();
            newCrimetxbx = new RadButtonTextBox();
            cancelbtn = new RadButton();
            radGridView1 = new RadGridView();
            investingDBBindingSource = new System.Windows.Forms.BindingSource(components);
            radLabel1 = new RadLabel();
            radLabel2 = new RadLabel();
            radLabelSerial = new RadLabel();
            InvPers = new RadButton();
            radLabel3 = new RadLabel();
            resm = new RadButton();
            word = new RadButton();
            crimeDropDownList = new RadDropDownList();
            DFDateTimePicker = new RadDateTimePicker();
            radButtonvehl = new RadButton();
            ((System.ComponentModel.ISupportInitialize)DMDateTimePicker).BeginInit();
            ((System.ComponentModel.ISupportInitialize)insertbtn).BeginInit();
            ((System.ComponentModel.ISupportInitialize)editbtn).BeginInit();
            ((System.ComponentModel.ISupportInitialize)deletebtn).BeginInit();
            ((System.ComponentModel.ISupportInitialize)refreshbtn).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radCheckBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radCheckBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)remtxtbx).BeginInit();
            ((System.ComponentModel.ISupportInitialize)newCrimetxbx).BeginInit();
            ((System.ComponentModel.ISupportInitialize)cancelbtn).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radGridView1.MasterTemplate).BeginInit();
            ((System.ComponentModel.ISupportInitialize)investingDBBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabelSerial).BeginInit();
            ((System.ComponentModel.ISupportInitialize)InvPers).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)resm).BeginInit();
            ((System.ComponentModel.ISupportInitialize)word).BeginInit();
            ((System.ComponentModel.ISupportInitialize)crimeDropDownList).BeginInit();
            ((System.ComponentModel.ISupportInitialize)DFDateTimePicker).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radButtonvehl).BeginInit();
            SuspendLayout();
            // 
            // DMDateTimePicker
            // 
            DMDateTimePicker.CalendarSize = new System.Drawing.Size(290, 320);
            DMDateTimePicker.Location = new System.Drawing.Point(57, 30);
            DMDateTimePicker.Margin = new System.Windows.Forms.Padding(1);
            DMDateTimePicker.Name = "DMDateTimePicker";
            DMDateTimePicker.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            DMDateTimePicker.Size = new System.Drawing.Size(261, 36);
            DMDateTimePicker.TabIndex = 34;
            DMDateTimePicker.TabStop = false;
            DMDateTimePicker.Text = "Wednesday, October 12, 2022";
            DMDateTimePicker.ThemeName = "MaterialBlueGrey";
            DMDateTimePicker.Value = new System.DateTime(2022, 10, 12, 10, 36, 40, 498);
            // 
            // insertbtn
            // 
            insertbtn.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            insertbtn.Location = new System.Drawing.Point(1126, 613);
            insertbtn.Name = "insertbtn";
            insertbtn.Size = new System.Drawing.Size(120, 36);
            insertbtn.TabIndex = 56;
            insertbtn.Text = "إدخال";
            insertbtn.ThemeName = "MaterialBlueGrey";
            insertbtn.Click += insertbtn_Click;
            // 
            // editbtn
            // 
            editbtn.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            editbtn.Location = new System.Drawing.Point(1000, 613);
            editbtn.Name = "editbtn";
            editbtn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            editbtn.Size = new System.Drawing.Size(120, 36);
            editbtn.TabIndex = 57;
            editbtn.Text = "تعديل";
            editbtn.ThemeName = "MaterialBlueGrey";
            editbtn.Click += editbtn_Click;
            // 
            // deletebtn
            // 
            deletebtn.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            deletebtn.Location = new System.Drawing.Point(874, 613);
            deletebtn.Name = "deletebtn";
            deletebtn.Size = new System.Drawing.Size(120, 36);
            deletebtn.TabIndex = 57;
            deletebtn.Text = "حذف";
            deletebtn.ThemeName = "MaterialBlueGrey";
            deletebtn.Click += deletebtn_Click;
            // 
            // refreshbtn
            // 
            refreshbtn.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            refreshbtn.Location = new System.Drawing.Point(748, 613);
            refreshbtn.Name = "refreshbtn";
            refreshbtn.Size = new System.Drawing.Size(120, 36);
            refreshbtn.TabIndex = 57;
            refreshbtn.Text = "تحديث";
            refreshbtn.ThemeName = "MaterialBlueGrey";
            refreshbtn.Click += newbtn_Click;
            // 
            // radCheckBox1
            // 
            radCheckBox1.Location = new System.Drawing.Point(912, 30);
            radCheckBox1.Name = "radCheckBox1";
            radCheckBox1.Size = new System.Drawing.Size(123, 19);
            radCheckBox1.TabIndex = 58;
            radCheckBox1.Text = "هل يوجد مضبوطات";
            radCheckBox1.ThemeName = "MaterialBlueGrey";
            // 
            // radCheckBox2
            // 
            radCheckBox2.Location = new System.Drawing.Point(929, 5);
            radCheckBox2.Name = "radCheckBox2";
            radCheckBox2.Size = new System.Drawing.Size(105, 19);
            radCheckBox2.TabIndex = 59;
            radCheckBox2.Text = "هل يوجد ملخص";
            radCheckBox2.ThemeName = "MaterialBlueGrey";
            // 
            // remtxtbx
            // 
            remtxtbx.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
            remtxtbx.Location = new System.Drawing.Point(6, 215);
            remtxtbx.Multiline = true;
            remtxtbx.Name = "remtxtbx";
            remtxtbx.NullText = "[موضوع المعامله]";
            remtxtbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // 
            // 
            remtxtbx.RootElement.StretchVertically = true;
            remtxtbx.ShowClearButton = true;
            remtxtbx.Size = new System.Drawing.Size(312, 351);
            remtxtbx.TabIndex = 0;
            remtxtbx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            remtxtbx.ThemeName = "MaterialBlueGrey";
            remtxtbx.TextChanged += remtxtbx_TextChanged;
            // 
            // newCrimetxbx
            // 
            newCrimetxbx.Location = new System.Drawing.Point(6, 135);
            newCrimetxbx.Margin = new System.Windows.Forms.Padding(1);
            newCrimetxbx.Name = "newCrimetxbx";
            newCrimetxbx.NullText = "[ادخال جرم جديد]";
            newCrimetxbx.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            newCrimetxbx.Size = new System.Drawing.Size(313, 37);
            newCrimetxbx.TabIndex = 54;
            newCrimetxbx.ThemeName = "MaterialBlueGrey";
            newCrimetxbx.TextChanged += newCrimetxbx_TextChanged;
            // 
            // cancelbtn
            // 
            cancelbtn.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            cancelbtn.Location = new System.Drawing.Point(622, 613);
            cancelbtn.Name = "cancelbtn";
            cancelbtn.Size = new System.Drawing.Size(120, 36);
            cancelbtn.TabIndex = 60;
            cancelbtn.Text = "الغاء";
            cancelbtn.ThemeName = "MaterialBlueGrey";
            cancelbtn.Click += cancelbtn_Click;
            // 
            // radGridView1
            // 
            radGridView1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            radGridView1.BackColor = System.Drawing.Color.Khaki;
            radGridView1.EnableCustomFiltering = true;
            radGridView1.EnableCustomGrouping = true;
            radGridView1.EnableCustomSorting = true;
            radGridView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            radGridView1.ForeColor = System.Drawing.Color.FromArgb(32, 32, 32);
            radGridView1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            radGridView1.Location = new System.Drawing.Point(323, 57);
            // 
            // 
            // 
            radGridView1.MasterTemplate.AllowAddNewRow = false;
            radGridView1.MasterTemplate.AllowColumnReorder = false;
            radGridView1.MasterTemplate.AutoSizeColumnsMode = GridViewAutoSizeColumnsMode.Fill;
            radGridView1.MasterTemplate.EnableAlternatingRowColor = true;
            radGridView1.MasterTemplate.EnableCustomFiltering = true;
            radGridView1.MasterTemplate.EnableCustomGrouping = true;
            radGridView1.MasterTemplate.EnableCustomSorting = true;
            radGridView1.MasterTemplate.EnableFiltering = true;
            radGridView1.MasterTemplate.EnableGrouping = false;
            radGridView1.MasterTemplate.ViewDefinition = tableViewDefinition1;
            radGridView1.Name = "radGridView1";
            radGridView1.ReadOnly = true;
            radGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            radGridView1.Size = new System.Drawing.Size(920, 509);
            radGridView1.TabIndex = 61;
            radGridView1.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel1
            // 
            radLabel1.BackColor = System.Drawing.Color.White;
            radLabel1.BorderVisible = true;
            radLabel1.ForeColor = System.Drawing.SystemColors.ControlText;
            radLabel1.Location = new System.Drawing.Point(243, 72);
            radLabel1.Name = "radLabel1";
            radLabel1.Size = new System.Drawing.Size(75, 21);
            radLabel1.TabIndex = 62;
            radLabel1.Text = "تاريخ المعاملة";
            radLabel1.TextAlignment = System.Drawing.ContentAlignment.TopRight;
            radLabel1.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel2
            // 
            radLabel2.BackColor = System.Drawing.Color.White;
            radLabel2.BorderVisible = true;
            radLabel2.Location = new System.Drawing.Point(243, 6);
            radLabel2.Name = "radLabel2";
            radLabel2.Size = new System.Drawing.Size(74, 21);
            radLabel2.TabIndex = 63;
            radLabel2.Text = "تاريخ الادخال";
            radLabel2.TextAlignment = System.Drawing.ContentAlignment.TopRight;
            radLabel2.ThemeName = "MaterialBlueGrey";
            // 
            // radLabelSerial
            // 
            radLabelSerial.BackColor = System.Drawing.Color.White;
            radLabelSerial.BorderVisible = true;
            radLabelSerial.Location = new System.Drawing.Point(384, 5);
            radLabelSerial.Name = "radLabelSerial";
            radLabelSerial.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            radLabelSerial.Size = new System.Drawing.Size(53, 21);
            radLabelSerial.TabIndex = 64;
            radLabelSerial.Text = "المتسلسل";
            radLabelSerial.TextAlignment = System.Drawing.ContentAlignment.TopRight;
            radLabelSerial.ThemeName = "MaterialBlueGrey";
            // 
            // InvPers
            // 
            InvPers.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            InvPers.Location = new System.Drawing.Point(496, 613);
            InvPers.Name = "InvPers";
            InvPers.Size = new System.Drawing.Size(120, 36);
            InvPers.TabIndex = 62;
            InvPers.Text = "أشخاص";
            InvPers.ThemeName = "MaterialBlueGrey";
            InvPers.Click += InvPers_Click;
            // 
            // radLabel3
            // 
            radLabel3.BackColor = System.Drawing.Color.White;
            radLabel3.BorderVisible = true;
            radLabel3.Location = new System.Drawing.Point(384, 28);
            radLabel3.Name = "radLabel3";
            radLabel3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            radLabel3.Size = new System.Drawing.Size(53, 21);
            radLabel3.TabIndex = 64;
            radLabel3.Text = "المتسلسل";
            radLabel3.TextAlignment = System.Drawing.ContentAlignment.TopRight;
            radLabel3.ThemeName = "MaterialBlueGrey";
            // 
            // resm
            // 
            resm.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            resm.Location = new System.Drawing.Point(118, 613);
            resm.Name = "resm";
            resm.Size = new System.Drawing.Size(120, 36);
            resm.TabIndex = 68;
            resm.Text = "ملخص";
            resm.ThemeName = "MaterialBlueGrey";
            resm.Click += resm_Click;
            // 
            // word
            // 
            word.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            word.Location = new System.Drawing.Point(370, 613);
            word.Name = "word";
            word.Size = new System.Drawing.Size(120, 36);
            word.TabIndex = 69;
            word.Text = "تصنيف";
            word.ThemeName = "MaterialBlueGrey";
            word.Click += word_Click;
            // 
            // crimeDropDownList
            // 
            crimeDropDownList.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            crimeDropDownList.DropDownAnimationEnabled = true;
            crimeDropDownList.Location = new System.Drawing.Point(6, 174);
            crimeDropDownList.Margin = new System.Windows.Forms.Padding(1);
            crimeDropDownList.Name = "crimeDropDownList";
            crimeDropDownList.NullText = "[الجرم]";
            crimeDropDownList.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            crimeDropDownList.Size = new System.Drawing.Size(313, 37);
            crimeDropDownList.TabIndex = 36;
            crimeDropDownList.ThemeName = "MaterialBlueGrey";
            // 
            // DFDateTimePicker
            // 
            DFDateTimePicker.CalendarSize = new System.Drawing.Size(290, 320);
            DFDateTimePicker.Location = new System.Drawing.Point(57, 97);
            DFDateTimePicker.Margin = new System.Windows.Forms.Padding(1);
            DFDateTimePicker.Name = "DFDateTimePicker";
            DFDateTimePicker.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            // 
            // 
            // 
            DFDateTimePicker.RootElement.AccessibleDescription = "Dfile";
            DFDateTimePicker.RootElement.AccessibleName = "Dfile";
            DFDateTimePicker.Size = new System.Drawing.Size(262, 36);
            DFDateTimePicker.TabIndex = 29;
            DFDateTimePicker.TabStop = false;
            DFDateTimePicker.Text = "Wednesday, October 12, 2022";
            DFDateTimePicker.ThemeName = "MaterialBlueGrey";
            DFDateTimePicker.Value = new System.DateTime(2022, 10, 12, 11, 56, 35, 0);
            // 
            // radButtonvehl
            // 
            radButtonvehl.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            radButtonvehl.Location = new System.Drawing.Point(244, 613);
            radButtonvehl.Name = "radButtonvehl";
            radButtonvehl.Size = new System.Drawing.Size(120, 36);
            radButtonvehl.TabIndex = 70;
            radButtonvehl.Text = "سيارات";
            radButtonvehl.ThemeName = "MaterialBlueGrey";
            radButtonvehl.Click += radButtonvehl_Click;
            // 
            // FormInvest
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.WhiteSmoke;
            ClientSize = new System.Drawing.Size(1248, 661);
            Controls.Add(radButtonvehl);
            Controls.Add(word);
            Controls.Add(resm);
            Controls.Add(InvPers);
            Controls.Add(radLabel3);
            Controls.Add(radLabelSerial);
            Controls.Add(radLabel2);
            Controls.Add(radLabel1);
            Controls.Add(radGridView1);
            Controls.Add(cancelbtn);
            Controls.Add(newCrimetxbx);
            Controls.Add(remtxtbx);
            Controls.Add(radCheckBox2);
            Controls.Add(radCheckBox1);
            Controls.Add(refreshbtn);
            Controls.Add(deletebtn);
            Controls.Add(editbtn);
            Controls.Add(insertbtn);
            Controls.Add(crimeDropDownList);
            Controls.Add(DMDateTimePicker);
            Controls.Add(DFDateTimePicker);
            Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            Name = "FormInvest";
            RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            Text = "FormInvest";
            Load += FormOrder_Load;
            ((System.ComponentModel.ISupportInitialize)DMDateTimePicker).EndInit();
            ((System.ComponentModel.ISupportInitialize)insertbtn).EndInit();
            ((System.ComponentModel.ISupportInitialize)editbtn).EndInit();
            ((System.ComponentModel.ISupportInitialize)deletebtn).EndInit();
            ((System.ComponentModel.ISupportInitialize)refreshbtn).EndInit();
            ((System.ComponentModel.ISupportInitialize)radCheckBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)radCheckBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)remtxtbx).EndInit();
            ((System.ComponentModel.ISupportInitialize)newCrimetxbx).EndInit();
            ((System.ComponentModel.ISupportInitialize)cancelbtn).EndInit();
            ((System.ComponentModel.ISupportInitialize)radGridView1.MasterTemplate).EndInit();
            ((System.ComponentModel.ISupportInitialize)radGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)investingDBBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel1).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel2).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabelSerial).EndInit();
            ((System.ComponentModel.ISupportInitialize)InvPers).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel3).EndInit();
            ((System.ComponentModel.ISupportInitialize)resm).EndInit();
            ((System.ComponentModel.ISupportInitialize)word).EndInit();
            ((System.ComponentModel.ISupportInitialize)crimeDropDownList).EndInit();
            ((System.ComponentModel.ISupportInitialize)DFDateTimePicker).EndInit();
            ((System.ComponentModel.ISupportInitialize)radButtonvehl).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private RadDateTimePicker DFDateTimePicker;
        private RadDateTimePicker DMDateTimePicker;
        private RadDropDownList crimeDropDownList;
        private Telerik.WinControls.Themes.MaterialBlueGreyTheme materialBlueGreyTheme1;
        private RadButton insertbtn;
        private RadButton editbtn;
        private RadButton deletebtn;
        private RadButton refreshbtn;
        private RadCheckBox radCheckBox1;
        private RadCheckBox radCheckBox2;
        private RadTextBox remtxtbx;
        private RadButtonTextBox newCrimetxbx;
        private RadButton cancelbtn;
        private RadGridView radGridView1;
        private RadLabel radLabel1;
        private RadLabel radLabel2;
        private RadLabel radLabelSerial;
        private RadButton InvPers;
        private RadLabel radLabel3;
        private RadButton resm;
        private RadButton word;
        private RadButton radButtonvehl;
        private System.Windows.Forms.BindingSource investingDBBindingSource;
    }
}