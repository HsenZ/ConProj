﻿//rabe3 sura
using AppSec.Repositorys.Utils;
using FontAwesome.Sharp;
using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;


namespace AppSec
{
    public partial class FormMainMenu : Form
    {
        #region "Def"
        private IconButton currentButton;
        private Random random;
        private int tempIndex;
        private Form activeForm;

        private string personnelID;

        public string PersonnelID
        {
            get { return personnelID; }
            set { personnelID = value; }
        }

        private string personnelName;

        public string PersonnelName
        {
            get { return personnelName; }
            set { personnelName = value; }
        }

        private string serialNo;

        public string SerialNo
        {
            get { return serialNo; }
            set { serialNo = value; }
        }
        #endregion

        #region "Constructors"
        public FormMainMenu()
        {
            InitializeComponent();
            random = new Random();
            iconButtonClose.Visible = false;
            this.Text = string.Empty;
            this.ControlBox = false;
            this.MaximizedBounds = Screen.FromHandle(this.Handle).WorkingArea;
        }
        #endregion        

        #region "Methods"
        // Methods that allow to move the panel through the title bar
        //[DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        //private extern static void ReleaseCapture();
        //[DllImport("user32.DLL", EntryPoint = "SendMessage")]
        //private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private Color SelectThemeColor()
        {
            int index = random.Next(ThemeColor.ColorList.Count);
            // If the color has already been selected, select again to choose a different one
            while (tempIndex == index)
            {
                index = random.Next(ThemeColor.ColorList.Count);
            }
            tempIndex = index;
            string color = ThemeColor.ColorList[index];
            return ColorTranslator.FromHtml(color);
        }

        private void ActivateButton(object btnSender)
        {
            // Highlight the button that was clicked (active form)
            // 1) Select a random color for the theme (optional, you can use a single color to highlight the button)
            // 2) Change button background color
            // 3) Change button font color
            // 4) Change the font size of the button
            if (btnSender != null)
            {
                if (currentButton != (IconButton)btnSender)
                {
                    DisableButton();
                    Color color = SelectThemeColor();
                    currentButton = (IconButton)btnSender;
                    currentButton.BackColor = color;
                    currentButton.ForeColor = Color.White;
                    currentButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    panelTitleBar.BackColor = color;
                    panelLogo.BackColor = ThemeColor.ChangeColorBrightness(color, -0.3);
                    ThemeColor.PrimaryColor = color;
                    ThemeColor.SecondaryColor = ThemeColor.ChangeColorBrightness(color, -0.3);
                    iconButtonClose.Visible = true;
                }
            }
        }
        private void DisableButton()
        {// Disable button highlighting-defaults
            foreach (Control previousBtn in panelMenu.Controls)
            {
                if (previousBtn.GetType() == typeof(IconButton))
                {
                    previousBtn.BackColor = Color.FromArgb(46, 46, 46);
                    previousBtn.ForeColor = Color.Gainsboro;
                    previousBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                }
            }
        }
        private void OpenChildForm(Form childForm, object btnSender)
        {
            if (activeForm != null)
                activeForm.Close();
            ActivateButton(btnSender);
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelDesktop.Controls.Add(childForm);
            panelDesktop.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            labelTitle.Text = childForm.Text;
        }
        private void Reset()
        {
            DisableButton();
            labelTitle.Text = "HOME";
            panelTitleBar.BackColor = Color.FromArgb(31, 31, 31);
            panelLogo.BackColor = Color.FromArgb(31, 31, 31);
            currentButton = null;
            iconButtonClose.Visible = false;
        }
        #endregion

        #region "Events"
        private void iconButtonProducts_Click(object sender, EventArgs e)
        {
            //OpenChildForm(new Forms.FormArcardReport(), sender);
        }

        private void iconButtonOrders_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.FormInvest(), sender);
        }

        private void iconButtonCustomers_Click(object sender, EventArgs e)
        {
            //OpenChildForm(new Forms.FormCriminals(), sender);


        }

        private void iconButtonReporting_Click(object sender, EventArgs e)
        {
            //OpenChildForm(new Forms.FormAnalysis(), sender);
        }

        private void iconButtonClose_Click(object sender, EventArgs e)
        {
            if (activeForm != null)
                activeForm.Close();
            Reset();
        }

        private void panelTitleBar_MouseDown(object sender, MouseEventArgs e)
        {
            //ReleaseCapture();
            //SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void iconButtonWinClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void iconButtonWinMax_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
                this.WindowState = FormWindowState.Maximized;
            else
                this.WindowState = FormWindowState.Normal;
        }

        private void iconButtonWinMin_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        #endregion

        private void Madboutbtn_Click(object sender, EventArgs e)
        {
            //OpenChildForm(new Forms.FormCrimes(), sender);
        }
    }
}