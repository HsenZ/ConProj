﻿namespace AppSec.Forms
{
    partial class FormVehicles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition1 = new Telerik.WinControls.UI.TableViewDefinition();
            Telerik.WinControls.UI.RadListDataItem radListDataItem1 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem2 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem3 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem4 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem5 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem6 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem7 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem8 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem9 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem10 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem11 = new Telerik.WinControls.UI.RadListDataItem();
            radLabel1 = new Telerik.WinControls.UI.RadLabel();
            txtSerial = new Telerik.WinControls.UI.RadTextBox();
            radLabel2 = new Telerik.WinControls.UI.RadLabel();
            txtVehicleId = new Telerik.WinControls.UI.RadTextBox();
            radGridView1 = new Telerik.WinControls.UI.RadGridView();
            telerikMetroBlueTheme1 = new Telerik.WinControls.Themes.TelerikMetroBlueTheme();
            radLabel3 = new Telerik.WinControls.UI.RadLabel();
            radLabel4 = new Telerik.WinControls.UI.RadLabel();
            radLabel5 = new Telerik.WinControls.UI.RadLabel();
            radLabel6 = new Telerik.WinControls.UI.RadLabel();
            radLabel7 = new Telerik.WinControls.UI.RadLabel();
            radLabel8 = new Telerik.WinControls.UI.RadLabel();
            radLabel9 = new Telerik.WinControls.UI.RadLabel();
            radLabel10 = new Telerik.WinControls.UI.RadLabel();
            radLabel11 = new Telerik.WinControls.UI.RadLabel();
            radLabel12 = new Telerik.WinControls.UI.RadLabel();
            radLabel13 = new Telerik.WinControls.UI.RadLabel();
            radLabel14 = new Telerik.WinControls.UI.RadLabel();
            radLabel15 = new Telerik.WinControls.UI.RadLabel();
            radLabel16 = new Telerik.WinControls.UI.RadLabel();
            radLabel17 = new Telerik.WinControls.UI.RadLabel();
            radLabel18 = new Telerik.WinControls.UI.RadLabel();
            radLabel19 = new Telerik.WinControls.UI.RadLabel();
            radLabel20 = new Telerik.WinControls.UI.RadLabel();
            radLabel21 = new Telerik.WinControls.UI.RadLabel();
            radLabel22 = new Telerik.WinControls.UI.RadLabel();
            radLabel23 = new Telerik.WinControls.UI.RadLabel();
            txtChassis = new Telerik.WinControls.UI.RadTextBox();
            txtMotor = new Telerik.WinControls.UI.RadTextBox();
            txtColor = new Telerik.WinControls.UI.RadTextBox();
            txtBrand = new Telerik.WinControls.UI.RadTextBox();
            txtModel = new Telerik.WinControls.UI.RadTextBox();
            txtDescription = new Telerik.WinControls.UI.RadTextBox();
            txtName = new Telerik.WinControls.UI.RadTextBox();
            txtLastName = new Telerik.WinControls.UI.RadTextBox();
            txtAddress = new Telerik.WinControls.UI.RadTextBox();
            txtDistrict = new Telerik.WinControls.UI.RadTextBox();
            txtMotherName = new Telerik.WinControls.UI.RadTextBox();
            nudAge = new System.Windows.Forms.NumericUpDown();
            radCheckBox1 = new Telerik.WinControls.UI.RadCheckBox();
            dtpProductionDate = new Telerik.WinControls.UI.RadDateTimePicker();
            dtpAquisitionDate = new Telerik.WinControls.UI.RadDateTimePicker();
            ddlCity = new Telerik.WinControls.UI.RadDropDownList();
            ddlBirthPlace = new Telerik.WinControls.UI.RadDropDownList();
            txtRegNum = new Telerik.WinControls.UI.RadMaskedEditBox();
            txtTelephon = new Telerik.WinControls.UI.RadMaskedEditBox();
            telephone = new Telerik.WinControls.UI.RadMaskedEditBox();
            btnAdd = new Telerik.WinControls.UI.RadButton();
            btnUpdate = new Telerik.WinControls.UI.RadButton();
            btnDelete = new Telerik.WinControls.UI.RadButton();
            btnReset = new Telerik.WinControls.UI.RadButton();
            radLabel24 = new Telerik.WinControls.UI.RadLabel();
            nudFirstLaunch = new System.Windows.Forms.NumericUpDown();
            ddlCode = new Telerik.WinControls.UI.RadDropDownList();
            txtNumber = new Telerik.WinControls.UI.RadMaskedEditBox();
            materialBlueGreyTheme1 = new Telerik.WinControls.Themes.MaterialBlueGreyTheme();
            ((System.ComponentModel.ISupportInitialize)radLabel1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)txtSerial).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)txtVehicleId).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radGridView1.MasterTemplate).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel17).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel18).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel19).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel20).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel21).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel22).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel23).BeginInit();
            ((System.ComponentModel.ISupportInitialize)txtChassis).BeginInit();
            ((System.ComponentModel.ISupportInitialize)txtMotor).BeginInit();
            ((System.ComponentModel.ISupportInitialize)txtColor).BeginInit();
            ((System.ComponentModel.ISupportInitialize)txtBrand).BeginInit();
            ((System.ComponentModel.ISupportInitialize)txtModel).BeginInit();
            ((System.ComponentModel.ISupportInitialize)txtDescription).BeginInit();
            ((System.ComponentModel.ISupportInitialize)txtName).BeginInit();
            ((System.ComponentModel.ISupportInitialize)txtLastName).BeginInit();
            ((System.ComponentModel.ISupportInitialize)txtAddress).BeginInit();
            ((System.ComponentModel.ISupportInitialize)txtDistrict).BeginInit();
            ((System.ComponentModel.ISupportInitialize)txtMotherName).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudAge).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radCheckBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dtpProductionDate).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dtpAquisitionDate).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ddlCity).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ddlBirthPlace).BeginInit();
            ((System.ComponentModel.ISupportInitialize)txtRegNum).BeginInit();
            ((System.ComponentModel.ISupportInitialize)txtTelephon).BeginInit();
            ((System.ComponentModel.ISupportInitialize)telephone).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnAdd).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnUpdate).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnDelete).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnReset).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel24).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudFirstLaunch).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ddlCode).BeginInit();
            ((System.ComponentModel.ISupportInitialize)txtNumber).BeginInit();
            SuspendLayout();
            // 
            // radLabel1
            // 
            radLabel1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            radLabel1.Location = new System.Drawing.Point(450, 5);
            radLabel1.Name = "radLabel1";
            radLabel1.Size = new System.Drawing.Size(91, 30);
            radLabel1.TabIndex = 0;
            radLabel1.Text = "المتسلسل";
            radLabel1.ThemeName = "MaterialBlueGrey";
            // 
            // txtSerial
            // 
            txtSerial.Location = new System.Drawing.Point(285, 5);
            txtSerial.Name = "txtSerial";
            txtSerial.ReadOnly = true;
            txtSerial.Size = new System.Drawing.Size(159, 37);
            txtSerial.TabIndex = 1;
            txtSerial.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel2
            // 
            radLabel2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            radLabel2.Location = new System.Drawing.Point(149, 5);
            radLabel2.Name = "radLabel2";
            radLabel2.Size = new System.Drawing.Size(93, 30);
            radLabel2.TabIndex = 2;
            radLabel2.Text = "Vehicle Id";
            radLabel2.ThemeName = "MaterialBlueGrey";
            // 
            // txtVehicleId
            // 
            txtVehicleId.Location = new System.Drawing.Point(12, 5);
            txtVehicleId.Name = "txtVehicleId";
            txtVehicleId.ReadOnly = true;
            txtVehicleId.Size = new System.Drawing.Size(125, 37);
            txtVehicleId.TabIndex = 3;
            txtVehicleId.ThemeName = "MaterialBlueGrey";
            // 
            // radGridView1
            // 
            radGridView1.Location = new System.Drawing.Point(547, 5);
            // 
            // 
            // 
            radGridView1.MasterTemplate.ViewDefinition = tableViewDefinition1;
            radGridView1.Name = "radGridView1";
            radGridView1.Size = new System.Drawing.Size(677, 417);
            radGridView1.TabIndex = 4;
            radGridView1.ThemeName = "MaterialBlueGrey";
            radGridView1.CurrentRowChanged += radGridView1_CurrentRowChanged;
            // 
            // radLabel3
            // 
            radLabel3.Location = new System.Drawing.Point(478, 55);
            radLabel3.Name = "radLabel3";
            radLabel3.Size = new System.Drawing.Size(63, 21);
            radLabel3.TabIndex = 5;
            radLabel3.Text = "رقم السيارة";
            radLabel3.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel4
            // 
            radLabel4.Location = new System.Drawing.Point(223, 48);
            radLabel4.Name = "radLabel4";
            radLabel4.Size = new System.Drawing.Size(35, 21);
            radLabel4.TabIndex = 6;
            radLabel4.Text = "الرمز";
            radLabel4.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel5
            // 
            radLabel5.Location = new System.Drawing.Point(190, 127);
            radLabel5.Name = "radLabel5";
            radLabel5.Size = new System.Drawing.Size(68, 21);
            radLabel5.TabIndex = 7;
            radLabel5.Text = "تأريخ الصنع";
            radLabel5.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel6
            // 
            radLabel6.Location = new System.Drawing.Point(200, 167);
            radLabel6.Name = "radLabel6";
            radLabel6.Size = new System.Drawing.Size(58, 21);
            radLabel6.TabIndex = 8;
            radLabel6.Text = "رقم الهيكل";
            radLabel6.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel7
            // 
            radLabel7.Location = new System.Drawing.Point(191, 207);
            radLabel7.Name = "radLabel7";
            radLabel7.Size = new System.Drawing.Size(66, 21);
            radLabel7.TabIndex = 9;
            radLabel7.Text = "رقم المحرك";
            radLabel7.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel8
            // 
            radLabel8.Location = new System.Drawing.Point(186, 420);
            radLabel8.Name = "radLabel8";
            radLabel8.Size = new System.Drawing.Size(71, 21);
            radLabel8.TabIndex = 10;
            radLabel8.Text = "تاريخ الشراء";
            radLabel8.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel9
            // 
            radLabel9.Location = new System.Drawing.Point(226, 247);
            radLabel9.Name = "radLabel9";
            radLabel9.Size = new System.Drawing.Size(32, 21);
            radLabel9.TabIndex = 11;
            radLabel9.Text = "اللون";
            radLabel9.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel10
            // 
            radLabel10.Location = new System.Drawing.Point(225, 331);
            radLabel10.Name = "radLabel10";
            radLabel10.Size = new System.Drawing.Size(33, 21);
            radLabel10.TabIndex = 12;
            radLabel10.Text = "النوع";
            radLabel10.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel11
            // 
            radLabel11.Location = new System.Drawing.Point(217, 288);
            radLabel11.Name = "radLabel11";
            radLabel11.Size = new System.Drawing.Size(41, 21);
            radLabel11.TabIndex = 13;
            radLabel11.Text = "الطراز";
            radLabel11.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel12
            // 
            radLabel12.Location = new System.Drawing.Point(196, 377);
            radLabel12.Name = "radLabel12";
            radLabel12.Size = new System.Drawing.Size(62, 21);
            radLabel12.TabIndex = 14;
            radLabel12.Text = "المواصفات";
            radLabel12.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel13
            // 
            radLabel13.Location = new System.Drawing.Point(502, 91);
            radLabel13.Name = "radLabel13";
            radLabel13.Size = new System.Drawing.Size(34, 21);
            radLabel13.TabIndex = 15;
            radLabel13.Text = "الاسم";
            radLabel13.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel14
            // 
            radLabel14.Location = new System.Drawing.Point(500, 176);
            radLabel14.Name = "radLabel14";
            radLabel14.Size = new System.Drawing.Size(36, 21);
            radLabel14.TabIndex = 16;
            radLabel14.Text = "العائله";
            radLabel14.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel15
            // 
            radLabel15.Location = new System.Drawing.Point(468, 361);
            radLabel15.Name = "radLabel15";
            radLabel15.Size = new System.Drawing.Size(79, 21);
            radLabel15.TabIndex = 17;
            radLabel15.Text = "رقم قبد النفوس";
            radLabel15.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel16
            // 
            radLabel16.Location = new System.Drawing.Point(494, 297);
            radLabel16.Name = "radLabel16";
            radLabel16.Size = new System.Drawing.Size(42, 21);
            radLabel16.TabIndex = 18;
            radLabel16.Text = "العنوان";
            radLabel16.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel17
            // 
            radLabel17.Location = new System.Drawing.Point(219, 468);
            radLabel17.Name = "radLabel17";
            radLabel17.Size = new System.Drawing.Size(39, 21);
            radLabel17.TabIndex = 19;
            radLabel17.Text = "المدينه";
            radLabel17.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel18
            // 
            radLabel18.Location = new System.Drawing.Point(482, 436);
            radLabel18.Name = "radLabel18";
            radLabel18.Size = new System.Drawing.Size(39, 21);
            radLabel18.TabIndex = 6;
            radLabel18.Text = "الاقامه";
            radLabel18.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel19
            // 
            radLabel19.Location = new System.Drawing.Point(490, 134);
            radLabel19.Name = "radLabel19";
            radLabel19.Size = new System.Drawing.Size(46, 21);
            radLabel19.TabIndex = 20;
            radLabel19.Text = "اسم الام";
            radLabel19.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel20
            // 
            radLabel20.Location = new System.Drawing.Point(198, 87);
            radLabel20.Name = "radLabel20";
            radLabel20.Size = new System.Drawing.Size(60, 21);
            radLabel20.TabIndex = 21;
            radLabel20.Text = "رقم الهاتف";
            radLabel20.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel21
            // 
            radLabel21.Location = new System.Drawing.Point(503, 219);
            radLabel21.Name = "radLabel21";
            radLabel21.Size = new System.Drawing.Size(33, 21);
            radLabel21.TabIndex = 22;
            radLabel21.Text = "العمر";
            radLabel21.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel22
            // 
            radLabel22.Location = new System.Drawing.Point(476, 254);
            radLabel22.Name = "radLabel22";
            radLabel22.Size = new System.Drawing.Size(64, 21);
            radLabel22.TabIndex = 23;
            radLabel22.Text = "محل الولاده";
            radLabel22.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel23
            // 
            radLabel23.Location = new System.Drawing.Point(440, 404);
            radLabel23.Name = "radLabel23";
            radLabel23.Size = new System.Drawing.Size(101, 21);
            radLabel23.TabIndex = 24;
            radLabel23.Text = "موضوعه في السير";
            radLabel23.ThemeName = "MaterialBlueGrey";
            // 
            // txtChassis
            // 
            txtChassis.Location = new System.Drawing.Point(12, 167);
            txtChassis.Name = "txtChassis";
            txtChassis.Size = new System.Drawing.Size(164, 37);
            txtChassis.TabIndex = 28;
            txtChassis.ThemeName = "MaterialBlueGrey";
            // 
            // txtMotor
            // 
            txtMotor.Location = new System.Drawing.Point(12, 207);
            txtMotor.Name = "txtMotor";
            txtMotor.Size = new System.Drawing.Size(164, 37);
            txtMotor.TabIndex = 29;
            txtMotor.ThemeName = "MaterialBlueGrey";
            // 
            // txtColor
            // 
            txtColor.Location = new System.Drawing.Point(12, 247);
            txtColor.Name = "txtColor";
            txtColor.Size = new System.Drawing.Size(164, 37);
            txtColor.TabIndex = 31;
            txtColor.ThemeName = "MaterialBlueGrey";
            // 
            // txtBrand
            // 
            txtBrand.Location = new System.Drawing.Point(12, 331);
            txtBrand.Name = "txtBrand";
            txtBrand.Size = new System.Drawing.Size(164, 37);
            txtBrand.TabIndex = 32;
            txtBrand.ThemeName = "MaterialBlueGrey";
            // 
            // txtModel
            // 
            txtModel.Location = new System.Drawing.Point(12, 288);
            txtModel.Name = "txtModel";
            txtModel.Size = new System.Drawing.Size(164, 37);
            txtModel.TabIndex = 33;
            txtModel.ThemeName = "MaterialBlueGrey";
            // 
            // txtDescription
            // 
            txtDescription.Location = new System.Drawing.Point(12, 377);
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new System.Drawing.Size(164, 37);
            txtDescription.TabIndex = 34;
            txtDescription.ThemeName = "MaterialBlueGrey";
            // 
            // txtName
            // 
            txtName.Location = new System.Drawing.Point(285, 91);
            txtName.Name = "txtName";
            txtName.Size = new System.Drawing.Size(184, 37);
            txtName.TabIndex = 35;
            txtName.ThemeName = "MaterialBlueGrey";
            // 
            // txtLastName
            // 
            txtLastName.Location = new System.Drawing.Point(285, 177);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new System.Drawing.Size(184, 37);
            txtLastName.TabIndex = 36;
            txtLastName.ThemeName = "MaterialBlueGrey";
            // 
            // txtAddress
            // 
            txtAddress.Location = new System.Drawing.Point(285, 289);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new System.Drawing.Size(184, 37);
            txtAddress.TabIndex = 38;
            txtAddress.ThemeName = "MaterialBlueGrey";
            // 
            // txtDistrict
            // 
            txtDistrict.Location = new System.Drawing.Point(285, 436);
            txtDistrict.Name = "txtDistrict";
            txtDistrict.Size = new System.Drawing.Size(184, 37);
            txtDistrict.TabIndex = 26;
            txtDistrict.ThemeName = "MaterialBlueGrey";
            // 
            // txtMotherName
            // 
            txtMotherName.Location = new System.Drawing.Point(285, 134);
            txtMotherName.Name = "txtMotherName";
            txtMotherName.Size = new System.Drawing.Size(184, 37);
            txtMotherName.TabIndex = 40;
            txtMotherName.ThemeName = "MaterialBlueGrey";
            // 
            // nudAge
            // 
            nudAge.Location = new System.Drawing.Point(285, 220);
            nudAge.Maximum = new decimal(new int[] { 90, 0, 0, 0 });
            nudAge.Minimum = new decimal(new int[] { 21, 0, 0, 0 });
            nudAge.Name = "nudAge";
            nudAge.Size = new System.Drawing.Size(184, 23);
            nudAge.TabIndex = 42;
            nudAge.Value = new decimal(new int[] { 21, 0, 0, 0 });
            // 
            // radCheckBox1
            // 
            radCheckBox1.Location = new System.Drawing.Point(285, 406);
            radCheckBox1.Name = "radCheckBox1";
            radCheckBox1.Size = new System.Drawing.Size(104, 19);
            radCheckBox1.TabIndex = 44;
            radCheckBox1.Text = "Out of Order";
            radCheckBox1.ThemeName = "MaterialBlueGrey";
            // 
            // dtpProductionDate
            // 
            dtpProductionDate.CalendarSize = new System.Drawing.Size(290, 320);
            dtpProductionDate.Location = new System.Drawing.Point(12, 127);
            dtpProductionDate.Name = "dtpProductionDate";
            dtpProductionDate.Size = new System.Drawing.Size(164, 36);
            dtpProductionDate.TabIndex = 45;
            dtpProductionDate.TabStop = false;
            dtpProductionDate.Text = "Saturday, May 20, 2023";
            dtpProductionDate.ThemeName = "MaterialBlueGrey";
            dtpProductionDate.Value = new System.DateTime(2023, 5, 20, 13, 2, 28, 349);
            // 
            // dtpAquisitionDate
            // 
            dtpAquisitionDate.CalendarSize = new System.Drawing.Size(290, 320);
            dtpAquisitionDate.Location = new System.Drawing.Point(9, 420);
            dtpAquisitionDate.Name = "dtpAquisitionDate";
            dtpAquisitionDate.Size = new System.Drawing.Size(167, 36);
            dtpAquisitionDate.TabIndex = 46;
            dtpAquisitionDate.TabStop = false;
            dtpAquisitionDate.Text = "Saturday, May 20, 2023";
            dtpAquisitionDate.ThemeName = "MaterialBlueGrey";
            dtpAquisitionDate.Value = new System.DateTime(2023, 5, 20, 13, 3, 4, 449);
            // 
            // ddlCity
            // 
            ddlCity.DropDownAnimationEnabled = true;
            ddlCity.Location = new System.Drawing.Point(12, 462);
            ddlCity.Name = "ddlCity";
            ddlCity.Size = new System.Drawing.Size(164, 37);
            ddlCity.TabIndex = 47;
            ddlCity.Text = "radDropDownList1";
            ddlCity.ThemeName = "MaterialBlueGrey";
            // 
            // ddlBirthPlace
            // 
            ddlBirthPlace.DropDownAnimationEnabled = true;
            ddlBirthPlace.Location = new System.Drawing.Point(285, 249);
            ddlBirthPlace.Name = "ddlBirthPlace";
            ddlBirthPlace.Size = new System.Drawing.Size(184, 37);
            ddlBirthPlace.TabIndex = 48;
            ddlBirthPlace.Text = "radDropDownList1";
            ddlBirthPlace.ThemeName = "MaterialBlueGrey";
            // 
            // txtRegNum
            // 
            txtRegNum.Location = new System.Drawing.Point(285, 361);
            txtRegNum.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            txtRegNum.Name = "txtRegNum";
            txtRegNum.Size = new System.Drawing.Size(184, 37);
            txtRegNum.TabIndex = 49;
            txtRegNum.TabStop = false;
            txtRegNum.Text = "0";
            txtRegNum.ThemeName = "MaterialBlueGrey";
            // 
            // txtTelephon
            // 
            txtTelephon.Location = new System.Drawing.Point(0, 0);
            txtTelephon.Name = "txtTelephon";
            txtTelephon.Size = new System.Drawing.Size(125, 20);
            txtTelephon.TabIndex = 0;
            txtTelephon.TabStop = false;
            // 
            // telephone
            // 
            telephone.Location = new System.Drawing.Point(12, 87);
            telephone.Mask = "+999-99-999-999";
            telephone.MaskType = Telerik.WinControls.UI.MaskType.Standard;
            telephone.Name = "telephone";
            telephone.Size = new System.Drawing.Size(164, 37);
            telephone.TabIndex = 50;
            telephone.TabStop = false;
            telephone.Text = "+___-__-___-___";
            telephone.ThemeName = "MaterialBlueGrey";
            // 
            // btnAdd
            // 
            btnAdd.BackColor = System.Drawing.SystemColors.ActiveCaption;
            btnAdd.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btnAdd.Location = new System.Drawing.Point(1107, 449);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new System.Drawing.Size(120, 36);
            btnAdd.TabIndex = 51;
            btnAdd.Text = "ادخال";
            btnAdd.ThemeName = "MaterialBlueGrey";
            btnAdd.Click += btnAdd_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = System.Drawing.SystemColors.ActiveCaption;
            btnUpdate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btnUpdate.Location = new System.Drawing.Point(980, 449);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new System.Drawing.Size(120, 36);
            btnUpdate.TabIndex = 52;
            btnUpdate.Text = "تعديل";
            btnUpdate.ThemeName = "MaterialBlueGrey";
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = System.Drawing.SystemColors.ActiveCaption;
            btnDelete.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btnDelete.Location = new System.Drawing.Point(849, 449);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new System.Drawing.Size(120, 36);
            btnDelete.TabIndex = 53;
            btnDelete.Text = "حذف";
            btnDelete.ThemeName = "MaterialBlueGrey";
            btnDelete.Click += btnDelete_Click;
            // 
            // btnReset
            // 
            btnReset.BackColor = System.Drawing.SystemColors.ActiveCaption;
            btnReset.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btnReset.Location = new System.Drawing.Point(719, 449);
            btnReset.Name = "btnReset";
            btnReset.Size = new System.Drawing.Size(120, 36);
            btnReset.TabIndex = 54;
            btnReset.Text = "الغاء";
            btnReset.ThemeName = "MaterialBlueGrey";
            btnReset.Click += btnReset_Click;
            // 
            // radLabel24
            // 
            radLabel24.Location = new System.Drawing.Point(443, 329);
            radLabel24.Name = "radLabel24";
            radLabel24.Size = new System.Drawing.Size(93, 21);
            radLabel24.TabIndex = 55;
            radLabel24.Text = "الوضع في لبخدمه";
            radLabel24.ThemeName = "MaterialBlueGrey";
            // 
            // nudFirstLaunch
            // 
            nudFirstLaunch.Location = new System.Drawing.Point(285, 332);
            nudFirstLaunch.Maximum = new decimal(new int[] { 2021, 0, 0, 0 });
            nudFirstLaunch.Minimum = new decimal(new int[] { 1950, 0, 0, 0 });
            nudFirstLaunch.Name = "nudFirstLaunch";
            nudFirstLaunch.Size = new System.Drawing.Size(152, 23);
            nudFirstLaunch.TabIndex = 56;
            nudFirstLaunch.Value = new decimal(new int[] { 1950, 0, 0, 0 });
            // 
            // ddlCode
            // 
            ddlCode.DropDownAnimationEnabled = true;
            radListDataItem1.Selected = true;
            radListDataItem1.Text = "No Code";
            radListDataItem2.Text = "A";
            radListDataItem3.Text = "B";
            radListDataItem4.Text = "G";
            radListDataItem5.Text = "M";
            radListDataItem6.Text = "N";
            radListDataItem7.Text = "O";
            radListDataItem8.Text = "P";
            radListDataItem9.Text = "S";
            radListDataItem10.Text = "T";
            radListDataItem11.Text = "Z";
            ddlCode.Items.Add(radListDataItem1);
            ddlCode.Items.Add(radListDataItem2);
            ddlCode.Items.Add(radListDataItem3);
            ddlCode.Items.Add(radListDataItem4);
            ddlCode.Items.Add(radListDataItem5);
            ddlCode.Items.Add(radListDataItem6);
            ddlCode.Items.Add(radListDataItem7);
            ddlCode.Items.Add(radListDataItem8);
            ddlCode.Items.Add(radListDataItem9);
            ddlCode.Items.Add(radListDataItem10);
            ddlCode.Items.Add(radListDataItem11);
            ddlCode.Location = new System.Drawing.Point(12, 46);
            ddlCode.Name = "ddlCode";
            ddlCode.Size = new System.Drawing.Size(125, 37);
            ddlCode.TabIndex = 57;
            ddlCode.Text = "No Code";
            ddlCode.ThemeName = "MaterialBlueGrey";
            // 
            // txtNumber
            // 
            txtNumber.Location = new System.Drawing.Point(285, 48);
            txtNumber.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            txtNumber.Name = "txtNumber";
            txtNumber.Size = new System.Drawing.Size(184, 37);
            txtNumber.TabIndex = 58;
            txtNumber.TabStop = false;
            txtNumber.Text = "0";
            txtNumber.ThemeName = "MaterialBlueGrey";
            // 
            // FormVehicles
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1236, 506);
            Controls.Add(txtNumber);
            Controls.Add(radLabel12);
            Controls.Add(ddlCode);
            Controls.Add(nudFirstLaunch);
            Controls.Add(radLabel24);
            Controls.Add(btnReset);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(telephone);
            Controls.Add(txtRegNum);
            Controls.Add(ddlBirthPlace);
            Controls.Add(ddlCity);
            Controls.Add(dtpAquisitionDate);
            Controls.Add(dtpProductionDate);
            Controls.Add(radCheckBox1);
            Controls.Add(nudAge);
            Controls.Add(txtMotherName);
            Controls.Add(txtDistrict);
            Controls.Add(txtAddress);
            Controls.Add(txtLastName);
            Controls.Add(txtName);
            Controls.Add(txtDescription);
            Controls.Add(txtModel);
            Controls.Add(txtBrand);
            Controls.Add(txtColor);
            Controls.Add(txtMotor);
            Controls.Add(txtChassis);
            Controls.Add(radLabel23);
            Controls.Add(radLabel22);
            Controls.Add(radLabel21);
            Controls.Add(radLabel20);
            Controls.Add(radLabel19);
            Controls.Add(radLabel18);
            Controls.Add(radLabel17);
            Controls.Add(radLabel16);
            Controls.Add(radLabel15);
            Controls.Add(radLabel14);
            Controls.Add(radLabel13);
            Controls.Add(radLabel11);
            Controls.Add(radLabel10);
            Controls.Add(radLabel9);
            Controls.Add(radLabel8);
            Controls.Add(radLabel7);
            Controls.Add(radLabel6);
            Controls.Add(radLabel5);
            Controls.Add(radLabel4);
            Controls.Add(radLabel3);
            Controls.Add(radGridView1);
            Controls.Add(txtVehicleId);
            Controls.Add(radLabel2);
            Controls.Add(txtSerial);
            Controls.Add(radLabel1);
            Name = "FormVehicles";
            Text = "FormVehicles";
            Load += FormVehicles_Load;
            ((System.ComponentModel.ISupportInitialize)radLabel1).EndInit();
            ((System.ComponentModel.ISupportInitialize)txtSerial).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel2).EndInit();
            ((System.ComponentModel.ISupportInitialize)txtVehicleId).EndInit();
            ((System.ComponentModel.ISupportInitialize)radGridView1.MasterTemplate).EndInit();
            ((System.ComponentModel.ISupportInitialize)radGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel3).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel4).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel5).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel6).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel7).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel8).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel9).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel10).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel11).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel12).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel13).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel14).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel15).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel16).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel17).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel18).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel19).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel20).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel21).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel22).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel23).EndInit();
            ((System.ComponentModel.ISupportInitialize)txtChassis).EndInit();
            ((System.ComponentModel.ISupportInitialize)txtMotor).EndInit();
            ((System.ComponentModel.ISupportInitialize)txtColor).EndInit();
            ((System.ComponentModel.ISupportInitialize)txtBrand).EndInit();
            ((System.ComponentModel.ISupportInitialize)txtModel).EndInit();
            ((System.ComponentModel.ISupportInitialize)txtDescription).EndInit();
            ((System.ComponentModel.ISupportInitialize)txtName).EndInit();
            ((System.ComponentModel.ISupportInitialize)txtLastName).EndInit();
            ((System.ComponentModel.ISupportInitialize)txtAddress).EndInit();
            ((System.ComponentModel.ISupportInitialize)txtDistrict).EndInit();
            ((System.ComponentModel.ISupportInitialize)txtMotherName).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudAge).EndInit();
            ((System.ComponentModel.ISupportInitialize)radCheckBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dtpProductionDate).EndInit();
            ((System.ComponentModel.ISupportInitialize)dtpAquisitionDate).EndInit();
            ((System.ComponentModel.ISupportInitialize)ddlCity).EndInit();
            ((System.ComponentModel.ISupportInitialize)ddlBirthPlace).EndInit();
            ((System.ComponentModel.ISupportInitialize)txtRegNum).EndInit();
            ((System.ComponentModel.ISupportInitialize)txtTelephon).EndInit();
            ((System.ComponentModel.ISupportInitialize)telephone).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnAdd).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnUpdate).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnDelete).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnReset).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel24).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudFirstLaunch).EndInit();
            ((System.ComponentModel.ISupportInitialize)ddlCode).EndInit();
            ((System.ComponentModel.ISupportInitialize)txtNumber).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadTextBox txtSerial;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadTextBox txtVehicleId;
        private Telerik.WinControls.UI.RadGridView radGridView1;
        private Telerik.WinControls.Themes.TelerikMetroBlueTheme telerikMetroBlueTheme1;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private Telerik.WinControls.UI.RadLabel radLabel4;
        private Telerik.WinControls.UI.RadLabel radLabel5;
        private Telerik.WinControls.UI.RadLabel radLabel6;
        private Telerik.WinControls.UI.RadLabel radLabel7;
        private Telerik.WinControls.UI.RadLabel radLabel8;
        private Telerik.WinControls.UI.RadLabel radLabel9;
        private Telerik.WinControls.UI.RadLabel radLabel10;
        private Telerik.WinControls.UI.RadLabel radLabel11;
        private Telerik.WinControls.UI.RadLabel radLabel12;
        private Telerik.WinControls.UI.RadLabel radLabel13;
        private Telerik.WinControls.UI.RadLabel radLabel14;
        private Telerik.WinControls.UI.RadLabel radLabel15;
        private Telerik.WinControls.UI.RadLabel radLabel16;
        private Telerik.WinControls.UI.RadLabel radLabel17;
        private Telerik.WinControls.UI.RadLabel radLabel18;
        private Telerik.WinControls.UI.RadLabel radLabel19;
        private Telerik.WinControls.UI.RadLabel radLabel20;
        private Telerik.WinControls.UI.RadLabel radLabel21;
        private Telerik.WinControls.UI.RadLabel radLabel22;
        private Telerik.WinControls.UI.RadLabel radLabel23;
        private Telerik.WinControls.UI.RadTextBox txtChassis;
        private Telerik.WinControls.UI.RadTextBox txtMotor;
        private Telerik.WinControls.UI.RadTextBox txtColor;
        private Telerik.WinControls.UI.RadTextBox txtBrand;
        private Telerik.WinControls.UI.RadTextBox txtModel;
        private Telerik.WinControls.UI.RadTextBox txtDescription;
        private Telerik.WinControls.UI.RadTextBox txtName;
        private Telerik.WinControls.UI.RadTextBox txtLastName;
        private Telerik.WinControls.UI.RadTextBox txtRegNumber;
        private Telerik.WinControls.UI.RadTextBox txtAddress;
        private Telerik.WinControls.UI.RadTextBox txtDistrict;
        private Telerik.WinControls.UI.RadTextBox txtMotherName;
        private Telerik.WinControls.UI.RadTextBox txtTelephone;
        private System.Windows.Forms.NumericUpDown nudAge;
        private Telerik.WinControls.UI.RadCheckBox radCheckBox1;
        private Telerik.WinControls.UI.RadDateTimePicker dtpProductionDate;
        private Telerik.WinControls.UI.RadDateTimePicker dtpAquisitionDate;
        private Telerik.WinControls.UI.RadDropDownList ddlCity;
        private Telerik.WinControls.UI.RadDropDownList ddlBirthPlace;
        private Telerik.WinControls.UI.RadMaskedEditBox txtRegNum;
        private Telerik.WinControls.UI.RadMaskedEditBox txtTelephon;
        private Telerik.WinControls.UI.RadMaskedEditBox telephone;
        private Telerik.WinControls.UI.RadButton btnAdd;
        private Telerik.WinControls.UI.RadButton btnUpdate;
        private Telerik.WinControls.UI.RadButton btnDelete;
        private Telerik.WinControls.UI.RadButton btnReset;
        private Telerik.WinControls.UI.RadLabel radLabel24;
        private System.Windows.Forms.NumericUpDown nudFirstLaunch;
        private Telerik.WinControls.UI.RadDropDownList ddlCode;
        private Telerik.WinControls.UI.RadMaskedEditBox txtNumber;
        private Telerik.WinControls.Themes.MaterialBlueGreyTheme materialBlueGreyTheme1;
    }
}