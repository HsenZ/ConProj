﻿

namespace AppSec
{
    partial class FormMainMenu
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            panelMenu = new System.Windows.Forms.Panel();
            Madboutbtn = new FontAwesome.Sharp.IconButton();
            iconButtonArcard = new FontAwesome.Sharp.IconButton();
            iconButtonInvpers = new FontAwesome.Sharp.IconButton();
            iconButtonInvest = new FontAwesome.Sharp.IconButton();
            iconButtonArcardsReport = new FontAwesome.Sharp.IconButton();
            panelLogo = new System.Windows.Forms.Panel();
            iconButtonLogo = new FontAwesome.Sharp.IconButton();
            panelTitleBar = new System.Windows.Forms.Panel();
            iconButtonWinMin = new FontAwesome.Sharp.IconButton();
            iconButtonWinMax = new FontAwesome.Sharp.IconButton();
            iconButtonWinClose = new FontAwesome.Sharp.IconButton();
            iconButtonClose = new FontAwesome.Sharp.IconButton();
            labelTitle = new System.Windows.Forms.Label();
            panelDesktop = new System.Windows.Forms.Panel();
            iconButtonLogoHome = new FontAwesome.Sharp.IconButton();
            panelMenu.SuspendLayout();
            panelLogo.SuspendLayout();
            panelTitleBar.SuspendLayout();
            panelDesktop.SuspendLayout();
            SuspendLayout();
            // 
            // panelMenu
            // 
            panelMenu.BackColor = System.Drawing.Color.FromArgb(46, 46, 46);
            panelMenu.Controls.Add(Madboutbtn);
            panelMenu.Controls.Add(iconButtonArcard);
            panelMenu.Controls.Add(iconButtonInvpers);
            panelMenu.Controls.Add(iconButtonInvest);
            panelMenu.Controls.Add(iconButtonArcardsReport);
            panelMenu.Controls.Add(panelLogo);
            panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            panelMenu.Location = new System.Drawing.Point(0, 0);
            panelMenu.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            panelMenu.Name = "panelMenu";
            panelMenu.Size = new System.Drawing.Size(200, 711);
            panelMenu.TabIndex = 0;
            // 
            // Madboutbtn
            // 
            Madboutbtn.Dock = System.Windows.Forms.DockStyle.Top;
            Madboutbtn.FlatAppearance.BorderSize = 0;
            Madboutbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            Madboutbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            Madboutbtn.ForeColor = System.Drawing.Color.Gainsboro;
            Madboutbtn.IconChar = FontAwesome.Sharp.IconChar.Handcuffs;
            Madboutbtn.IconColor = System.Drawing.Color.Gainsboro;
            Madboutbtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            Madboutbtn.IconSize = 32;
            Madboutbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            Madboutbtn.Location = new System.Drawing.Point(0, 443);
            Madboutbtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            Madboutbtn.Name = "Madboutbtn";
            Madboutbtn.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            Madboutbtn.Size = new System.Drawing.Size(200, 92);
            Madboutbtn.TabIndex = 5;
            Madboutbtn.Text = "الجرائم";
            Madboutbtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            Madboutbtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            Madboutbtn.UseVisualStyleBackColor = true;
            Madboutbtn.Click += Madboutbtn_Click;
            // 
            // iconButtonArcard
            // 
            iconButtonArcard.Dock = System.Windows.Forms.DockStyle.Top;
            iconButtonArcard.FlatAppearance.BorderSize = 0;
            iconButtonArcard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            iconButtonArcard.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            iconButtonArcard.ForeColor = System.Drawing.Color.Gainsboro;
            iconButtonArcard.IconChar = FontAwesome.Sharp.IconChar.AreaChart;
            iconButtonArcard.IconColor = System.Drawing.Color.Gainsboro;
            iconButtonArcard.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconButtonArcard.IconSize = 32;
            iconButtonArcard.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            iconButtonArcard.Location = new System.Drawing.Point(0, 351);
            iconButtonArcard.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            iconButtonArcard.Name = "iconButtonArcard";
            iconButtonArcard.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            iconButtonArcard.Size = new System.Drawing.Size(200, 92);
            iconButtonArcard.TabIndex = 4;
            iconButtonArcard.Text = "احصائيات";
            iconButtonArcard.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            iconButtonArcard.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            iconButtonArcard.UseVisualStyleBackColor = true;
            iconButtonArcard.Click += iconButtonReporting_Click;
            // 
            // iconButtonInvpers
            // 
            iconButtonInvpers.Dock = System.Windows.Forms.DockStyle.Top;
            iconButtonInvpers.FlatAppearance.BorderSize = 0;
            iconButtonInvpers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            iconButtonInvpers.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            iconButtonInvpers.ForeColor = System.Drawing.Color.Gainsboro;
            iconButtonInvpers.IconChar = FontAwesome.Sharp.IconChar.Users;
            iconButtonInvpers.IconColor = System.Drawing.Color.Gainsboro;
            iconButtonInvpers.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconButtonInvpers.IconSize = 32;
            iconButtonInvpers.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            iconButtonInvpers.Location = new System.Drawing.Point(0, 259);
            iconButtonInvpers.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            iconButtonInvpers.Name = "iconButtonInvpers";
            iconButtonInvpers.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            iconButtonInvpers.Size = new System.Drawing.Size(200, 92);
            iconButtonInvpers.TabIndex = 3;
            iconButtonInvpers.Text = "المتهمين";
            iconButtonInvpers.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            iconButtonInvpers.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            iconButtonInvpers.UseVisualStyleBackColor = true;
            iconButtonInvpers.Click += iconButtonCustomers_Click;
            // 
            // iconButtonInvest
            // 
            iconButtonInvest.Dock = System.Windows.Forms.DockStyle.Top;
            iconButtonInvest.FlatAppearance.BorderSize = 0;
            iconButtonInvest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            iconButtonInvest.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            iconButtonInvest.ForeColor = System.Drawing.Color.Gainsboro;
            iconButtonInvest.IconChar = FontAwesome.Sharp.IconChar.ListCheck;
            iconButtonInvest.IconColor = System.Drawing.Color.Gainsboro;
            iconButtonInvest.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconButtonInvest.IconSize = 32;
            iconButtonInvest.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            iconButtonInvest.Location = new System.Drawing.Point(0, 167);
            iconButtonInvest.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            iconButtonInvest.Name = "iconButtonInvest";
            iconButtonInvest.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            iconButtonInvest.Size = new System.Drawing.Size(200, 92);
            iconButtonInvest.TabIndex = 2;
            iconButtonInvest.Text = "ادخال";
            iconButtonInvest.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            iconButtonInvest.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            iconButtonInvest.UseVisualStyleBackColor = true;
            iconButtonInvest.Click += iconButtonOrders_Click;
            // 
            // iconButtonArcardsReport
            // 
            iconButtonArcardsReport.Dock = System.Windows.Forms.DockStyle.Top;
            iconButtonArcardsReport.FlatAppearance.BorderSize = 0;
            iconButtonArcardsReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            iconButtonArcardsReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            iconButtonArcardsReport.ForeColor = System.Drawing.Color.Gainsboro;
            iconButtonArcardsReport.IconChar = FontAwesome.Sharp.IconChar.ChartGantt;
            iconButtonArcardsReport.IconColor = System.Drawing.Color.Gainsboro;
            iconButtonArcardsReport.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconButtonArcardsReport.IconSize = 32;
            iconButtonArcardsReport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            iconButtonArcardsReport.Location = new System.Drawing.Point(0, 75);
            iconButtonArcardsReport.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            iconButtonArcardsReport.Name = "iconButtonArcardsReport";
            iconButtonArcardsReport.Padding = new System.Windows.Forms.Padding(14, 0, 0, 0);
            iconButtonArcardsReport.Size = new System.Drawing.Size(200, 92);
            iconButtonArcardsReport.TabIndex = 1;
            iconButtonArcardsReport.Text = "تقارير";
            iconButtonArcardsReport.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            iconButtonArcardsReport.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            iconButtonArcardsReport.UseVisualStyleBackColor = true;
            iconButtonArcardsReport.Click += iconButtonProducts_Click;
            // 
            // panelLogo
            // 
            panelLogo.BackColor = System.Drawing.Color.FromArgb(31, 31, 31);
            panelLogo.Controls.Add(iconButtonLogo);
            panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            panelLogo.Location = new System.Drawing.Point(0, 0);
            panelLogo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            panelLogo.Name = "panelLogo";
            panelLogo.Size = new System.Drawing.Size(200, 75);
            panelLogo.TabIndex = 0;
            // 
            // iconButtonLogo
            // 
            iconButtonLogo.Anchor = System.Windows.Forms.AnchorStyles.None;
            iconButtonLogo.FlatAppearance.BorderSize = 0;
            iconButtonLogo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            iconButtonLogo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            iconButtonLogo.ForeColor = System.Drawing.Color.White;
            iconButtonLogo.IconChar = FontAwesome.Sharp.IconChar.Book;
            iconButtonLogo.IconColor = System.Drawing.Color.White;
            iconButtonLogo.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconButtonLogo.IconSize = 52;
            iconButtonLogo.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            iconButtonLogo.Location = new System.Drawing.Point(-14, -10);
            iconButtonLogo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            iconButtonLogo.Name = "iconButtonLogo";
            iconButtonLogo.Size = new System.Drawing.Size(200, 82);
            iconButtonLogo.TabIndex = 0;
            iconButtonLogo.Text = "My Logo";
            iconButtonLogo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            iconButtonLogo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            iconButtonLogo.UseVisualStyleBackColor = true;
            // 
            // panelTitleBar
            // 
            panelTitleBar.BackColor = System.Drawing.Color.WhiteSmoke;
            panelTitleBar.Controls.Add(iconButtonWinMin);
            panelTitleBar.Controls.Add(iconButtonWinMax);
            panelTitleBar.Controls.Add(iconButtonWinClose);
            panelTitleBar.Controls.Add(iconButtonClose);
            panelTitleBar.Controls.Add(labelTitle);
            panelTitleBar.Dock = System.Windows.Forms.DockStyle.Top;
            panelTitleBar.Location = new System.Drawing.Point(200, 0);
            panelTitleBar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            panelTitleBar.Name = "panelTitleBar";
            panelTitleBar.Size = new System.Drawing.Size(1059, 75);
            panelTitleBar.TabIndex = 1;
            panelTitleBar.MouseDown += panelTitleBar_MouseDown;
            // 
            // iconButtonWinMin
            // 
            iconButtonWinMin.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            iconButtonWinMin.FlatAppearance.BorderSize = 0;
            iconButtonWinMin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            iconButtonWinMin.ForeColor = System.Drawing.Color.Gainsboro;
            iconButtonWinMin.IconChar = FontAwesome.Sharp.IconChar.WindowMinimize;
            iconButtonWinMin.IconColor = System.Drawing.Color.Silver;
            iconButtonWinMin.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconButtonWinMin.IconSize = 28;
            iconButtonWinMin.Location = new System.Drawing.Point(944, 7);
            iconButtonWinMin.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            iconButtonWinMin.Name = "iconButtonWinMin";
            iconButtonWinMin.Size = new System.Drawing.Size(33, 32);
            iconButtonWinMin.TabIndex = 4;
            iconButtonWinMin.UseVisualStyleBackColor = true;
            iconButtonWinMin.Click += iconButtonWinMin_Click;
            // 
            // iconButtonWinMax
            // 
            iconButtonWinMax.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            iconButtonWinMax.FlatAppearance.BorderSize = 0;
            iconButtonWinMax.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            iconButtonWinMax.ForeColor = System.Drawing.Color.Gainsboro;
            iconButtonWinMax.IconChar = FontAwesome.Sharp.IconChar.WindowMaximize;
            iconButtonWinMax.IconColor = System.Drawing.Color.Silver;
            iconButtonWinMax.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconButtonWinMax.IconSize = 28;
            iconButtonWinMax.Location = new System.Drawing.Point(984, 7);
            iconButtonWinMax.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            iconButtonWinMax.Name = "iconButtonWinMax";
            iconButtonWinMax.Size = new System.Drawing.Size(33, 32);
            iconButtonWinMax.TabIndex = 3;
            iconButtonWinMax.UseVisualStyleBackColor = true;
            iconButtonWinMax.Click += iconButtonWinMax_Click;
            // 
            // iconButtonWinClose
            // 
            iconButtonWinClose.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            iconButtonWinClose.FlatAppearance.BorderSize = 0;
            iconButtonWinClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            iconButtonWinClose.ForeColor = System.Drawing.Color.Gainsboro;
            iconButtonWinClose.IconChar = FontAwesome.Sharp.IconChar.RectangleXmark;
            iconButtonWinClose.IconColor = System.Drawing.Color.Silver;
            iconButtonWinClose.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconButtonWinClose.IconSize = 28;
            iconButtonWinClose.Location = new System.Drawing.Point(1023, 7);
            iconButtonWinClose.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            iconButtonWinClose.Name = "iconButtonWinClose";
            iconButtonWinClose.Size = new System.Drawing.Size(33, 32);
            iconButtonWinClose.TabIndex = 2;
            iconButtonWinClose.UseVisualStyleBackColor = true;
            iconButtonWinClose.Click += iconButtonWinClose_Click;
            // 
            // iconButtonClose
            // 
            iconButtonClose.FlatAppearance.BorderSize = 0;
            iconButtonClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            iconButtonClose.ForeColor = System.Drawing.Color.White;
            iconButtonClose.IconChar = FontAwesome.Sharp.IconChar.Multiply;
            iconButtonClose.IconColor = System.Drawing.Color.Silver;
            iconButtonClose.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconButtonClose.IconSize = 32;
            iconButtonClose.Location = new System.Drawing.Point(7, 36);
            iconButtonClose.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            iconButtonClose.Name = "iconButtonClose";
            iconButtonClose.Size = new System.Drawing.Size(37, 37);
            iconButtonClose.TabIndex = 1;
            iconButtonClose.UseVisualStyleBackColor = true;
            iconButtonClose.Click += iconButtonClose_Click;
            // 
            // labelTitle
            // 
            labelTitle.Anchor = System.Windows.Forms.AnchorStyles.None;
            labelTitle.AutoSize = true;
            labelTitle.Font = new System.Drawing.Font("Microsoft New Tai Lue", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            labelTitle.ForeColor = System.Drawing.Color.Indigo;
            labelTitle.Location = new System.Drawing.Point(478, 1);
            labelTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            labelTitle.Name = "labelTitle";
            labelTitle.Size = new System.Drawing.Size(73, 27);
            labelTitle.TabIndex = 0;
            labelTitle.Text = "HOME";
            // 
            // panelDesktop
            // 
            panelDesktop.BackColor = System.Drawing.Color.WhiteSmoke;
            panelDesktop.Controls.Add(iconButtonLogoHome);
            panelDesktop.Dock = System.Windows.Forms.DockStyle.Fill;
            panelDesktop.Location = new System.Drawing.Point(200, 75);
            panelDesktop.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            panelDesktop.Name = "panelDesktop";
            panelDesktop.Size = new System.Drawing.Size(1059, 636);
            panelDesktop.TabIndex = 2;
            // 
            // iconButtonLogoHome
            // 
            iconButtonLogoHome.Anchor = System.Windows.Forms.AnchorStyles.None;
            iconButtonLogoHome.FlatAppearance.BorderSize = 0;
            iconButtonLogoHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            iconButtonLogoHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            iconButtonLogoHome.ForeColor = System.Drawing.Color.FromArgb(113, 96, 232);
            iconButtonLogoHome.IconChar = FontAwesome.Sharp.IconChar.LocationCrosshairs;
            iconButtonLogoHome.IconColor = System.Drawing.Color.FromArgb(113, 96, 232);
            iconButtonLogoHome.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconButtonLogoHome.IconSize = 180;
            iconButtonLogoHome.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            iconButtonLogoHome.Location = new System.Drawing.Point(425, 161);
            iconButtonLogoHome.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            iconButtonLogoHome.MinimumSize = new System.Drawing.Size(140, 138);
            iconButtonLogoHome.Name = "iconButtonLogoHome";
            iconButtonLogoHome.Size = new System.Drawing.Size(210, 208);
            iconButtonLogoHome.TabIndex = 1;
            iconButtonLogoHome.Text = "My Logo";
            iconButtonLogoHome.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            iconButtonLogoHome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            iconButtonLogoHome.UseVisualStyleBackColor = true;
            // 
            // FormMainMenu
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1259, 711);
            Controls.Add(panelDesktop);
            Controls.Add(panelTitleBar);
            Controls.Add(panelMenu);
            Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            MinimumSize = new System.Drawing.Size(697, 456);
            Name = "FormMainMenu";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "Form1";
            panelMenu.ResumeLayout(false);
            panelLogo.ResumeLayout(false);
            panelTitleBar.ResumeLayout(false);
            panelTitleBar.PerformLayout();
            panelDesktop.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Panel panelLogo;
        private FontAwesome.Sharp.IconButton iconButtonArcard;
        private FontAwesome.Sharp.IconButton iconButtonInvpers;
        private FontAwesome.Sharp.IconButton iconButtonInvest;
        private FontAwesome.Sharp.IconButton iconButtonArcardsReport;
        private System.Windows.Forms.Panel panelTitleBar;
        private System.Windows.Forms.Label labelTitle;
        private FontAwesome.Sharp.IconButton iconButtonLogo;
        private System.Windows.Forms.Panel panelDesktop;
        private FontAwesome.Sharp.IconButton iconButtonClose;
        private FontAwesome.Sharp.IconButton iconButtonLogoHome;
        private FontAwesome.Sharp.IconButton iconButtonWinClose;
        private FontAwesome.Sharp.IconButton iconButtonWinMin;
        private FontAwesome.Sharp.IconButton iconButtonWinMax;
        private FontAwesome.Sharp.IconButton Madboutbtn;
    }
}

