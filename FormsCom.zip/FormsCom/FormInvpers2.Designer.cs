﻿namespace AppSec.Forms
{
    partial class FormInvpers2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Telerik.WinControls.UI.RadListDataItem radListDataItem1 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem2 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem3 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem4 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition1 = new Telerik.WinControls.UI.TableViewDefinition();
            Telerik.WinControls.UI.RadListDataItem radListDataItem5 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem6 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem7 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem8 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem9 = new Telerik.WinControls.UI.RadListDataItem();
            Telerik.WinControls.UI.RadListDataItem radListDataItem10 = new Telerik.WinControls.UI.RadListDataItem();
            update = new System.Windows.Forms.Button();
            delete = new System.Windows.Forms.Button();
            Insert = new System.Windows.Forms.Button();
            radLabelSerial = new Telerik.WinControls.UI.RadLabel();
            radLabel1 = new Telerik.WinControls.UI.RadLabel();
            serperstxbx = new Telerik.WinControls.UI.RadTextBox();
            Lname = new Telerik.WinControls.UI.RadButtonTextBox();
            Fname = new Telerik.WinControls.UI.RadButtonTextBox();
            Mother = new Telerik.WinControls.UI.RadButtonTextBox();
            Father = new Telerik.WinControls.UI.RadButtonTextBox();
            reg = new Telerik.WinControls.UI.RadButtonTextBox();
            materialBlueGreyTheme1 = new Telerik.WinControls.Themes.MaterialBlueGreyTheme();
            NationDDL = new Telerik.WinControls.UI.RadDropDownList();
            PbirthDDL = new Telerik.WinControls.UI.RadDropDownList();
            ResidDDL = new Telerik.WinControls.UI.RadDropDownList();
            attrDDL = new Telerik.WinControls.UI.RadDropDownList();
            Pbirth = new Telerik.WinControls.UI.RadButtonTextBox();
            Resid = new Telerik.WinControls.UI.RadButtonTextBox();
            Adrs = new Telerik.WinControls.UI.RadCheckBox();
            Exist = new Telerik.WinControls.UI.RadCheckBox();
            radGridView1 = new Telerik.WinControls.UI.RadGridView();
            invperBindingSource = new System.Windows.Forms.BindingSource(components);
            Serialtxbx = new Telerik.WinControls.UI.RadTextBox();
            Dbirth = new Telerik.WinControls.UI.RadButtonTextBox();
            cancel = new System.Windows.Forms.Button();
            radNICKNAMETextBox = new Telerik.WinControls.UI.RadButtonTextBox();
            radOCCUPATIONTextBox = new Telerik.WinControls.UI.RadButtonTextBox();
            rMobileNo = new Telerik.WinControls.UI.RadMaskedEditBox();
            radMaskedEditBox1 = new Telerik.WinControls.UI.RadMaskedEditBox();
            radDropDownList1 = new Telerik.WinControls.UI.RadDropDownList();
            radDropDownList2 = new Telerik.WinControls.UI.RadDropDownList();
            arch = new Telerik.WinControls.UI.RadButtonTextBox();
            ((System.ComponentModel.ISupportInitialize)radLabelSerial).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radLabel1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)serperstxbx).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Lname).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Fname).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Mother).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Father).BeginInit();
            ((System.ComponentModel.ISupportInitialize)reg).BeginInit();
            ((System.ComponentModel.ISupportInitialize)NationDDL).BeginInit();
            ((System.ComponentModel.ISupportInitialize)PbirthDDL).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ResidDDL).BeginInit();
            ((System.ComponentModel.ISupportInitialize)attrDDL).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Pbirth).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Resid).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Adrs).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Exist).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radGridView1.MasterTemplate).BeginInit();
            ((System.ComponentModel.ISupportInitialize)invperBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Serialtxbx).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Dbirth).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radNICKNAMETextBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radOCCUPATIONTextBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)rMobileNo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radMaskedEditBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radDropDownList1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)radDropDownList2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)arch).BeginInit();
            SuspendLayout();
            // 
            // update
            // 
            update.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            update.Location = new System.Drawing.Point(796, 450);
            update.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            update.Name = "update";
            update.Size = new System.Drawing.Size(140, 46);
            update.TabIndex = 16;
            update.Text = "تعديل";
            update.UseVisualStyleBackColor = true;
            update.Click += update_Click;
            // 
            // delete
            // 
            delete.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            delete.Location = new System.Drawing.Point(943, 450);
            delete.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            delete.Name = "delete";
            delete.Size = new System.Drawing.Size(140, 46);
            delete.TabIndex = 15;
            delete.Text = "حذف";
            delete.UseVisualStyleBackColor = true;
            delete.Click += delete_Click;
            // 
            // Insert
            // 
            Insert.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            Insert.Location = new System.Drawing.Point(1090, 450);
            Insert.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            Insert.Name = "Insert";
            Insert.Size = new System.Drawing.Size(140, 46);
            Insert.TabIndex = 14;
            Insert.Text = "ادخال";
            Insert.UseVisualStyleBackColor = true;
            Insert.Click += Insert_Click;
            // 
            // radLabelSerial
            // 
            radLabelSerial.BackColor = System.Drawing.Color.White;
            radLabelSerial.Location = new System.Drawing.Point(201, 10);
            radLabelSerial.Name = "radLabelSerial";
            radLabelSerial.Size = new System.Drawing.Size(112, 21);
            radLabelSerial.TabIndex = 65;
            radLabelSerial.Text = "الرقم المتسلسل للملف";
            radLabelSerial.TextAlignment = System.Drawing.ContentAlignment.TopRight;
            radLabelSerial.ThemeName = "MaterialBlueGrey";
            // 
            // radLabel1
            // 
            radLabel1.BackColor = System.Drawing.Color.White;
            radLabel1.Location = new System.Drawing.Point(12, 12);
            radLabel1.Name = "radLabel1";
            radLabel1.Size = new System.Drawing.Size(125, 21);
            radLabel1.TabIndex = 69;
            radLabel1.Text = "الرقم المتسلسل للشخص";
            radLabel1.TextAlignment = System.Drawing.ContentAlignment.TopRight;
            radLabel1.ThemeName = "MaterialBlueGrey";
            // 
            // serperstxbx
            // 
            serperstxbx.BackColor = System.Drawing.Color.White;
            serperstxbx.Location = new System.Drawing.Point(143, -4);
            serperstxbx.Name = "serperstxbx";
            serperstxbx.NullText = "0";
            serperstxbx.ReadOnly = true;
            serperstxbx.Size = new System.Drawing.Size(52, 37);
            serperstxbx.TabIndex = 70;
            serperstxbx.ThemeName = "MaterialBlueGrey";
            // 
            // Lname
            // 
            Lname.Location = new System.Drawing.Point(12, 37);
            Lname.Name = "Lname";
            Lname.NullText = "[الشهرة]";
            Lname.Size = new System.Drawing.Size(183, 37);
            Lname.TabIndex = 71;
            Lname.ThemeName = "MaterialBlueGrey";
            Lname.TextChanged += Lname_TextChanged;
            // 
            // Fname
            // 
            Fname.Location = new System.Drawing.Point(201, 37);
            Fname.Name = "Fname";
            Fname.NullText = "[الإسم]";
            Fname.Size = new System.Drawing.Size(180, 37);
            Fname.TabIndex = 72;
            Fname.ThemeName = "MaterialBlueGrey";
            Fname.TextChanged += Fname_TextChanged;
            // 
            // Mother
            // 
            Mother.Location = new System.Drawing.Point(12, 80);
            Mother.Name = "Mother";
            Mother.NullText = "[إسم الأم]";
            Mother.Size = new System.Drawing.Size(183, 37);
            Mother.TabIndex = 73;
            Mother.ThemeName = "MaterialBlueGrey";
            Mother.TextChanged += Mother_TextChanged;
            // 
            // Father
            // 
            Father.Location = new System.Drawing.Point(201, 80);
            Father.Name = "Father";
            Father.NullText = "[إسم اللأب]";
            Father.Size = new System.Drawing.Size(180, 37);
            Father.TabIndex = 74;
            Father.ThemeName = "MaterialBlueGrey";
            Father.TextChanged += Father_TextChanged;
            // 
            // reg
            // 
            reg.Location = new System.Drawing.Point(12, 123);
            reg.Name = "reg";
            reg.NullText = "[رقم ومكان السجل]";
            reg.Size = new System.Drawing.Size(369, 37);
            reg.TabIndex = 72;
            reg.ThemeName = "MaterialBlueGrey";
            reg.TextChanged += reg_TextChanged;
            // 
            // NationDDL
            // 
            NationDDL.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            NationDDL.DropDownAnimationEnabled = true;
            radListDataItem1.Text = "الجرم";
            NationDDL.Items.Add(radListDataItem1);
            NationDDL.Location = new System.Drawing.Point(12, 164);
            NationDDL.Margin = new System.Windows.Forms.Padding(1);
            NationDDL.Name = "NationDDL";
            NationDDL.NullText = "[الجنسية]";
            NationDDL.Size = new System.Drawing.Size(221, 37);
            NationDDL.TabIndex = 37;
            NationDDL.ThemeName = "MaterialBlueGrey";
            // 
            // PbirthDDL
            // 
            PbirthDDL.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            PbirthDDL.DropDownAnimationEnabled = true;
            radListDataItem2.Text = "الجرم";
            PbirthDDL.Items.Add(radListDataItem2);
            PbirthDDL.Location = new System.Drawing.Point(12, 203);
            PbirthDDL.Margin = new System.Windows.Forms.Padding(1);
            PbirthDDL.Name = "PbirthDDL";
            PbirthDDL.NullText = "[محل الولادة]";
            PbirthDDL.Size = new System.Drawing.Size(221, 37);
            PbirthDDL.TabIndex = 75;
            PbirthDDL.ThemeName = "MaterialBlueGrey";
            // 
            // ResidDDL
            // 
            ResidDDL.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            ResidDDL.DropDownAnimationEnabled = true;
            radListDataItem3.Text = "الجرم";
            ResidDDL.Items.Add(radListDataItem3);
            ResidDDL.Location = new System.Drawing.Point(12, 242);
            ResidDDL.Margin = new System.Windows.Forms.Padding(1);
            ResidDDL.Name = "ResidDDL";
            ResidDDL.NullText = "[محل الإقامة]";
            ResidDDL.Size = new System.Drawing.Size(221, 37);
            ResidDDL.TabIndex = 76;
            ResidDDL.ThemeName = "MaterialBlueGrey";
            ResidDDL.SelectedIndexChanged += ResidDDL_SelectedIndexChanged_1;
            // 
            // attrDDL
            // 
            attrDDL.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            attrDDL.DropDownAnimationEnabled = true;
            radListDataItem4.Text = "الجرم";
            attrDDL.Items.Add(radListDataItem4);
            attrDDL.Location = new System.Drawing.Point(12, 281);
            attrDDL.Margin = new System.Windows.Forms.Padding(1);
            attrDDL.Name = "attrDDL";
            attrDDL.NullText = "[الصفة]";
            attrDDL.Size = new System.Drawing.Size(221, 37);
            attrDDL.TabIndex = 77;
            attrDDL.ThemeName = "MaterialBlueGrey";
            // 
            // Pbirth
            // 
            Pbirth.EmbeddedLabelText = "[محل الولادة]";
            Pbirth.Location = new System.Drawing.Point(237, 203);
            Pbirth.Name = "Pbirth";
            Pbirth.NullText = "[محل الولادة]";
            Pbirth.Size = new System.Drawing.Size(144, 37);
            Pbirth.TabIndex = 72;
            Pbirth.ThemeName = "MaterialBlueGrey";
            Pbirth.TextChanged += Pbirth_TextChanged;
            // 
            // Resid
            // 
            Resid.EmbeddedLabelText = "[محل الإقامة]";
            Resid.Location = new System.Drawing.Point(237, 242);
            Resid.Name = "Resid";
            Resid.NullText = "[محل الإقامة]";
            Resid.Size = new System.Drawing.Size(144, 37);
            Resid.TabIndex = 79;
            Resid.ThemeName = "MaterialBlueGrey";
            Resid.TextChanged += Resid_TextChanged;
            // 
            // Adrs
            // 
            Adrs.Location = new System.Drawing.Point(253, 365);
            Adrs.Name = "Adrs";
            Adrs.Size = new System.Drawing.Size(128, 19);
            Adrs.TabIndex = 80;
            Adrs.Text = "هل يوجد عنوان سكن";
            Adrs.ThemeName = "MaterialBlueGrey";
            // 
            // Exist
            // 
            Exist.Location = new System.Drawing.Point(260, 390);
            Exist.Name = "Exist";
            Exist.Size = new System.Drawing.Size(121, 19);
            Exist.TabIndex = 81;
            Exist.Text = "هل يوجد رقم داخلي";
            Exist.ThemeName = "MaterialBlueGrey";
            // 
            // radGridView1
            // 
            radGridView1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            radGridView1.AutoSizeRows = true;
            radGridView1.BackColor = System.Drawing.SystemColors.Control;
            radGridView1.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            radGridView1.ForeColor = System.Drawing.Color.FromArgb(32, 32, 32);
            radGridView1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            radGridView1.Location = new System.Drawing.Point(387, 10);
            // 
            // 
            // 
            radGridView1.MasterTemplate.EnableAlternatingRowColor = true;
            radGridView1.MasterTemplate.EnableFiltering = true;
            radGridView1.MasterTemplate.ViewDefinition = tableViewDefinition1;
            radGridView1.Name = "radGridView1";
            radGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            radGridView1.Size = new System.Drawing.Size(851, 434);
            radGridView1.TabIndex = 82;
            radGridView1.ThemeName = "MaterialBlueGrey";
            // 
            // Serialtxbx
            // 
            Serialtxbx.BackColor = System.Drawing.Color.White;
            Serialtxbx.Location = new System.Drawing.Point(329, -4);
            Serialtxbx.Name = "Serialtxbx";
            Serialtxbx.ReadOnly = true;
            Serialtxbx.Size = new System.Drawing.Size(52, 37);
            Serialtxbx.TabIndex = 71;
            Serialtxbx.ThemeName = "MaterialBlueGrey";
            // 
            // Dbirth
            // 
            Dbirth.EmbeddedLabelText = "محضر رقم";
            Dbirth.Location = new System.Drawing.Point(272, 322);
            Dbirth.Name = "Dbirth";
            Dbirth.NullText = "[تأريخ الولادة]";
            Dbirth.Size = new System.Drawing.Size(109, 37);
            Dbirth.TabIndex = 79;
            Dbirth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            Dbirth.ThemeName = "MaterialBlueGrey";
            Dbirth.TextChanged += Dbirth_TextChanged;
            // 
            // cancel
            // 
            cancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;
            cancel.Location = new System.Drawing.Point(648, 450);
            cancel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            cancel.Name = "cancel";
            cancel.Size = new System.Drawing.Size(140, 46);
            cancel.TabIndex = 83;
            cancel.Text = "الغاء";
            cancel.UseVisualStyleBackColor = true;
            cancel.Click += cancel_Click;
            // 
            // radNICKNAMETextBox
            // 
            radNICKNAMETextBox.ForeColor = System.Drawing.Color.Brown;
            radNICKNAMETextBox.Location = new System.Drawing.Point(15, 372);
            radNICKNAMETextBox.Name = "radNICKNAMETextBox";
            radNICKNAMETextBox.NullText = "[اللقب]";
            radNICKNAMETextBox.Size = new System.Drawing.Size(180, 37);
            radNICKNAMETextBox.TabIndex = 84;
            radNICKNAMETextBox.ThemeName = "MaterialBlueGrey";
            // 
            // radOCCUPATIONTextBox
            // 
            radOCCUPATIONTextBox.ForeColor = System.Drawing.Color.Brown;
            radOCCUPATIONTextBox.Location = new System.Drawing.Point(15, 415);
            radOCCUPATIONTextBox.Name = "radOCCUPATIONTextBox";
            radOCCUPATIONTextBox.NullText = "[المهنة]";
            radOCCUPATIONTextBox.Size = new System.Drawing.Size(180, 37);
            radOCCUPATIONTextBox.TabIndex = 87;
            radOCCUPATIONTextBox.ThemeName = "MaterialBlueGrey";
            radOCCUPATIONTextBox.TextChanged += radOCCUPATIONTextBox_TextChanged;
            // 
            // rMobileNo
            // 
            rMobileNo.ForeColor = System.Drawing.Color.Brown;
            rMobileNo.Location = new System.Drawing.Point(15, 458);
            rMobileNo.Mask = "+999-99-999-999";
            rMobileNo.MaskType = Telerik.WinControls.UI.MaskType.Standard;
            rMobileNo.Name = "rMobileNo";
            rMobileNo.RightToLeft = System.Windows.Forms.RightToLeft.No;
            rMobileNo.Size = new System.Drawing.Size(180, 37);
            rMobileNo.TabIndex = 89;
            rMobileNo.TabStop = false;
            rMobileNo.Text = "+___-__-___-___";
            rMobileNo.ThemeName = "MaterialBlueGrey";
            // 
            // radMaskedEditBox1
            // 
            radMaskedEditBox1.ForeColor = System.Drawing.Color.Brown;
            radMaskedEditBox1.Location = new System.Drawing.Point(201, 416);
            radMaskedEditBox1.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            radMaskedEditBox1.Name = "radMaskedEditBox1";
            radMaskedEditBox1.NullText = "رقم الهوية";
            radMaskedEditBox1.Size = new System.Drawing.Size(180, 37);
            radMaskedEditBox1.TabIndex = 90;
            radMaskedEditBox1.TabStop = false;
            radMaskedEditBox1.Text = "0";
            radMaskedEditBox1.ThemeName = "MaterialBlueGrey";
            // 
            // radDropDownList1
            // 
            radDropDownList1.DropDownAnimationEnabled = true;
            radDropDownList1.ForeColor = System.Drawing.Color.Brown;
            radListDataItem5.Text = "ذكر";
            radListDataItem6.Text = "انثى";
            radDropDownList1.Items.Add(radListDataItem5);
            radDropDownList1.Items.Add(radListDataItem6);
            radDropDownList1.Location = new System.Drawing.Point(387, 459);
            radDropDownList1.Name = "radDropDownList1";
            radDropDownList1.NullText = "الجنس";
            radDropDownList1.Size = new System.Drawing.Size(123, 37);
            radDropDownList1.TabIndex = 91;
            radDropDownList1.ThemeName = "MaterialBlueGrey";
            // 
            // radDropDownList2
            // 
            radDropDownList2.DropDownAnimationEnabled = true;
            radDropDownList2.ForeColor = System.Drawing.Color.Brown;
            radListDataItem7.Text = "متزوج";
            radListDataItem8.Text = "اعذب";
            radListDataItem9.Text = "مطلق";
            radListDataItem10.Text = "ارمل";
            radDropDownList2.Items.Add(radListDataItem7);
            radDropDownList2.Items.Add(radListDataItem8);
            radDropDownList2.Items.Add(radListDataItem9);
            radDropDownList2.Items.Add(radListDataItem10);
            radDropDownList2.Location = new System.Drawing.Point(201, 459);
            radDropDownList2.Name = "radDropDownList2";
            radDropDownList2.NullText = "الحالة الاجتماعية";
            radDropDownList2.Size = new System.Drawing.Size(180, 37);
            radDropDownList2.TabIndex = 92;
            radDropDownList2.ThemeName = "MaterialBlueGrey";
            // 
            // arch
            // 
            arch.EmbeddedLabelText = "محضر رقم";
            arch.Location = new System.Drawing.Point(104, 322);
            arch.Name = "arch";
            arch.NullText = "[الرقم في الداخلي]";
            arch.Size = new System.Drawing.Size(129, 37);
            arch.TabIndex = 78;
            arch.ThemeName = "MaterialBlueGrey";
            arch.TextChanged += arch_TextChanged;
            // Hide the control
            arch.Visible = false;
            arch.Text = "0";
            // 
            // FormInvpers2
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.WhiteSmoke;
            ClientSize = new System.Drawing.Size(1244, 519);
            Controls.Add(radDropDownList2);
            Controls.Add(radDropDownList1);
            Controls.Add(radMaskedEditBox1);
            Controls.Add(rMobileNo);
            Controls.Add(radOCCUPATIONTextBox);
            Controls.Add(radNICKNAMETextBox);
            Controls.Add(cancel);
            Controls.Add(Dbirth);
            Controls.Add(Serialtxbx);
            Controls.Add(radGridView1);
            Controls.Add(Exist);
            Controls.Add(Adrs);
            Controls.Add(Resid);
            Controls.Add(Pbirth);
            Controls.Add(arch);
            Controls.Add(attrDDL);
            Controls.Add(ResidDDL);
            Controls.Add(PbirthDDL);
            Controls.Add(NationDDL);
            Controls.Add(reg);
            Controls.Add(Father);
            Controls.Add(Mother);
            Controls.Add(Fname);
            Controls.Add(Lname);
            Controls.Add(serperstxbx);
            Controls.Add(radLabel1);
            Controls.Add(radLabelSerial);
            Controls.Add(update);
            Controls.Add(delete);
            Controls.Add(Insert);
            Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            Name = "FormInvpers2";
            RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            Text = "الأشخاص";
            Load += FormCustomer_Load;
            ((System.ComponentModel.ISupportInitialize)radLabelSerial).EndInit();
            ((System.ComponentModel.ISupportInitialize)radLabel1).EndInit();
            ((System.ComponentModel.ISupportInitialize)serperstxbx).EndInit();
            ((System.ComponentModel.ISupportInitialize)Lname).EndInit();
            ((System.ComponentModel.ISupportInitialize)Fname).EndInit();
            ((System.ComponentModel.ISupportInitialize)Mother).EndInit();
            ((System.ComponentModel.ISupportInitialize)Father).EndInit();
            ((System.ComponentModel.ISupportInitialize)reg).EndInit();
            ((System.ComponentModel.ISupportInitialize)NationDDL).EndInit();
            ((System.ComponentModel.ISupportInitialize)PbirthDDL).EndInit();
            ((System.ComponentModel.ISupportInitialize)ResidDDL).EndInit();
            ((System.ComponentModel.ISupportInitialize)attrDDL).EndInit();
            ((System.ComponentModel.ISupportInitialize)Pbirth).EndInit();
            ((System.ComponentModel.ISupportInitialize)Resid).EndInit();
            ((System.ComponentModel.ISupportInitialize)Adrs).EndInit();
            ((System.ComponentModel.ISupportInitialize)Exist).EndInit();
            ((System.ComponentModel.ISupportInitialize)radGridView1.MasterTemplate).EndInit();
            ((System.ComponentModel.ISupportInitialize)radGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)invperBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)Serialtxbx).EndInit();
            ((System.ComponentModel.ISupportInitialize)Dbirth).EndInit();
            ((System.ComponentModel.ISupportInitialize)radNICKNAMETextBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)radOCCUPATIONTextBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)rMobileNo).EndInit();
            ((System.ComponentModel.ISupportInitialize)radMaskedEditBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)radDropDownList1).EndInit();
            ((System.ComponentModel.ISupportInitialize)radDropDownList2).EndInit();
            ((System.ComponentModel.ISupportInitialize)arch).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button Insert;
        private Telerik.WinControls.UI.RadLabel radLabelSerial;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadTextBox serperstxbx;
        private Telerik.WinControls.UI.RadButtonTextBox Lname;
        private Telerik.WinControls.UI.RadButtonTextBox Fname;
        private Telerik.WinControls.UI.RadButtonTextBox Mother;
        private Telerik.WinControls.UI.RadButtonTextBox Father;
        private Telerik.WinControls.UI.RadButtonTextBox reg;
        private Telerik.WinControls.Themes.MaterialBlueGreyTheme materialBlueGreyTheme1;
        private Telerik.WinControls.UI.RadDropDownList NationDDL;
        private Telerik.WinControls.UI.RadDropDownList PbirthDDL;
        private Telerik.WinControls.UI.RadDropDownList ResidDDL;
        private Telerik.WinControls.UI.RadDropDownList attrDDL;
        private Telerik.WinControls.UI.RadButtonTextBox Pbirth;
        private Telerik.WinControls.UI.RadButtonTextBox Resid;
        private Telerik.WinControls.UI.RadCheckBox Adrs;
        private Telerik.WinControls.UI.RadCheckBox Exist;
        private Telerik.WinControls.UI.RadGridView radGridView1;
        private Telerik.WinControls.UI.RadTextBox Serialtxbx;
        private System.Windows.Forms.BindingSource invperBindingSource;
        private Telerik.WinControls.UI.RadButtonTextBox Dbirth;
        private System.Windows.Forms.Button cancel;
        private Telerik.WinControls.UI.RadButtonTextBox radNICKNAMETextBox;
        private Telerik.WinControls.UI.RadButtonTextBox radOCCUPATIONTextBox;
        private Telerik.WinControls.UI.RadMaskedEditBox rMobileNo;
        private Telerik.WinControls.UI.RadMaskedEditBox radMaskedEditBox1;
        private Telerik.WinControls.UI.RadDropDownList radDropDownList1;
        private Telerik.WinControls.UI.RadDropDownList radDropDownList2;
        private Telerik.WinControls.UI.RadButtonTextBox arch;
    }
}